#!/usr/bin/env bash
# _setup_pdf_translate_portable.sh
set -euo pipefail

DIR="${1:-ArO_PDF2PL_portable}"
FROM="${2:-en}"
TO="${3:-pl}"

mkdir -p "$DIR"
cd "$DIR"

python3 -m venv .venv
source .venv/bin/activate

python -m pip install --upgrade pip
python -m pip install argostranslate

# argospm (manager modeli) jest w ekosystemie Argos; wg docs: update/search/install :contentReference[oaicite:1]{index=1}
argospm update
PKG="translate-${FROM}_${TO}"
echo "[*] Instaluję model: $PKG"
argospm install "$PKG"

echo
echo "[✓] Portable gotowy w: $DIR"
echo "Uruchamianie:"
echo "  source $DIR/.venv/bin/activate"
echo "  argospm list"

