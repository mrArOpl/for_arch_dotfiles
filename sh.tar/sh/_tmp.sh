#!/bin/bash
# This script displays a greeting
echo "Hello, world!"
echo "Today is $(date)."
echo "Your current directory is: $(pwd)"
echo "Your PATH is: $PATH"
