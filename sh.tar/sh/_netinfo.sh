#!/bin/bash
# 
clear
netstat -aen | grep tcp
netstat -aen | grep udp
ip a
echo ' Pause '
read
clear
netstat -i;
watch n-1 'netstat -ae | grep tcp*udp'
echo 'ctrl+c close'
#
# as(c)2019

