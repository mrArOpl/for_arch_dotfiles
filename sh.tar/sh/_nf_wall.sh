#!/bin/bash

# CZYSZCZENIE STARYCH REGUŁ
nft flush ruleset

# USTAWIENIE POLITYKI DZIAŁANIA
nft add table inet filter
nft add chain inet filter input { type filter hook input priority 0 \; policy drop \; }
nft add chain inet filter forward { type filter hook forward priority 0 \; policy drop \; }
nft add chain inet filter output { type filter hook output priority 0 \; policy accept \; }

# AKCEPTUJEMY POŁĄCZENIA ZALEŻNE OD ISTNIEJĄCEJ SESJI
nft add rule inet filter input ct state established,related accept

# AKCEPTUJEMY PINGI (ICMP)
nft add rule inet filter input icmp type echo-request accept

# BLOKOWANIE TELNETU
nft add rule inet filter input tcp dport telnet drop
nft add rule inet filter output tcp sport telnet drop

# ZAPIS DO LOGA ODRZUCONYCH PAKIETÓW
nft add chain inet filter logging { type filter hook input priority 0 \; policy drop \; }
nft add rule inet filter input log prefix "IPTables-Dropped: " drop

# OCHRONA PRZED ATAKIEM PING OF DEATH
nft add rule inet filter input icmp type echo-request limit rate 1/second accept

echo "Firewall z nftables został skonfigurowany."

