#!/bin/bash

# _terminator_pro.sh - Skrypt uruchamiający Terminatora z różnymi opcjami, w tym z Firejail i izolacją
# Autor: OG
# Wybierz opcję przed uruchomieniem Terminatora

echo "Wybierz opcję:"
echo "1. Czysty Terminator (bez Firejail)"
echo "2. Terminator z Firejail (prywatny katalog domowy i konfiguracja .bashrc)"
echo "3. Terminator z Firejail (prywatny katalog domowy i konfiguracja .bashrc, bez DNS)"
echo "4. Terminator z Firejail (prywatny katalog domowy, konfiguracja .bashrc, bez DNS i sieci)"
echo "5. Pełna izolacja z Firejail (prywatny katalog, pełna izolacja)"

# Odczytanie wyboru użytkownika
read -p "Wybór (1-5): " choice

case $choice in
  1)
    # Opcja 1: Czysty Terminator bez Firejail
    echo "Uruchamianie czystego Terminatora..."
    terminator -l 3_1
    ;;

  2)
    # Opcja 2: Firejail z prywatnym katalogiem domowym i .bashrc
    echo "Uruchamianie Terminatora z Firejail (prywatny katalog, konfiguracja .bashrc)..."
    firejail --private --env=~/.bashrc terminator -l 3_1
    ;;

  3)
    # Opcja 3: Firejail z prywatnym katalogiem, .bashrc i bez DNS
    echo "Uruchamianie Terminatora z Firejail (prywatny katalog, .bashrc, bez DNS)..."
    firejail --private --env=~/.bashrc --dns=none terminator -l 3_1
    ;;

  4)
    # Opcja 4: Firejail z prywatnym katalogiem, .bashrc, bez DNS i wyłączeniem sieci
    echo "Uruchamianie Terminatora z Firejail (prywatny katalog, .bashrc, bez DNS, bez sieci)..."
    firejail --private --env=~/.bashrc --dns=none --net=none terminator -l 3_1
    ;;

  5)
    # Opcja 5: Pełna izolacja z Firejail
    echo "Uruchamianie Terminatora z pełną izolacją w Firejail..."
    firejail --private terminator -l 3_1
    ;;

  *)
    # Jeśli użytkownik wybierze niepoprawną opcję
    echo "Nieprawidłowy wybór. Proszę wybrać numer od 1 do 5."
    ;;
esac
