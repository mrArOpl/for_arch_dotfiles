#!/usr/bin/bash
###############
#  INSTALL:
#  sudo bash _manjaro_install.sh  
#  greate etitors: geany, pluma, mousepad
#
#  Made by ArO from POLAND, contact: mail: dr.code@tuta.io , https//:mr-aro.site
#                                    
#
###############
clear
echo ' Manjaro install soft (c)2026 ArO '
echo ' Please before update and upgrade linux... '
pacman -Sy
pacman -S net-tools speedtest-cli
pacman -S brave-browser chromium vivaldi     # mullvad , floorp - portable, manual
pacman -S doublecmd-qt5     # copy .config/ and download portable
pacman -S terminator tilda   # copy .config/
pacman -S geany
pacman -S bluefish
pacman -S gnome-disk-utility partitiomanager
pacman -S xpdf atril
pacman -S mc
pacman -S pluma gedit
pacman -S mtr iftop
pacman -S veracrypt bitwarden ventoy
pacman -S vokoscreen
pacman -S ristretto krita pinta mat2
pacman -S seahorse
pacman -S nmap vulscan
pacman -S pitivi
pacman -S obs-studio
pacman -S smplayer parole
# pacman -S guvcview movit motion tvtime wire-desktop srs openshot nageru openshot baresip avidemux-qt gnome-video-effects cheese flowblade kdenlive
pacman -S hplip
pacman -S composer
pacman -S abiword
pacman -S neofetch fastfetch screenfetch uwufetch
pacman -S figlet toilet beep
pacman -S dnscrypt-proxy dnscrypt-wrapper
# pacman -S libredefender
pacman -S libreoffice-fresh            # stil - stabilna, czcionki (emotki) - install
pacman -S libreoffice-fresh-pl
pacman -S yt-dlp ytfzf
pacman -S pv
pacman -S epiphany netsurf pix pkgbrowser
pacman -S qbittorrent
pacman -S pdfcrack xreader zsh-doc mupdf-gl mupdf-tools texworks gscan2pdf pdfslicer pdfmixtool
pacman -S phpldapadmin
pacman -S python-pip python-xyz python-pipx
pacman -S scrcpy apksigcopier
pacman -S vinagre tigervnc gtk-vnc
pacman -S remmina krdc
pacman -S fuseiso brasero
pacman -S eza # fork exa
pacman -S firetools
#
# pacman -S gpg-crypter fscrypt gnugpg2   # check
# install from menu virtualbox(guest,iso,ext.,mod) & virtmanager
# firewall allow ports: 5555 , 5900
# check net: netstat -tuae(n)
# disable avahi: systemctl stop avahi-daemon.service
#
echo ' '
echo ' Manjaro install soft (c)2024.10 ArO -------->  END   <---------- '
###
#############################################################################################################################################################
