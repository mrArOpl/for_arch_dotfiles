#!/bin/bash

base_dir="$(pwd)"

# Pobierz wszystkie partycje (bez sprawdzania czy zamontowane)
partitions=$(lsblk -lnpo NAME,TYPE | awk '$2=="part" {print $1}')

for part in $partitions; do
    name=$(basename "$part")
    mount_dir="$base_dir/$name"

    # Tworzenie katalogu montowania
    if [ ! -d "$mount_dir" ]; then
        mkdir -p "$mount_dir"
    fi

    # Zapytanie użytkownika o tryb montowania
    while true; do
        read -rp "Zamontować $part jako RW (odczyt/zapis) czy RO (tylko do odczytu)? [RW/RO]: " mode
        case $mode in
            RW|rw)
                mount "$part" "$mount_dir"
                echo "$part zamontowano w $mount_dir jako RW"
                break
                ;;
            RO|ro)
                mount -o ro "$part" "$mount_dir"
                echo "$part zamontowano w $mount_dir jako RO"
                break
                ;;
            *)
                echo "Nieprawidłowy wybór. Wpisz RW albo RO."
                ;;
        esac
    done
done

