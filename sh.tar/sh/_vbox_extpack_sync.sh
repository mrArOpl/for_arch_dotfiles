#!/bin/bash
# _vbox_extpack_sync.sh
# Auto-sync Oracle VM VirtualBox Extension Pack z wersją VirtualBoxa
# by ArO + AI (OG edition)

set -e

VBOXM="VBoxManage"

# --- Helpers ---
err() { echo -e "[ERR] $*" >&2; }
info() { echo -e "[..] $*"; }
ok() { echo -e "[OK] $*"; }

# --- 1. Sprawdź VBoxManage ---
if ! command -v "$VBOXM" >/dev/null 2>&1; then
    err "Nie znaleziono VBoxManage. Zainstaluj VirtualBox z repo, potem odpal skrypt."
    exit 1
fi

# --- 2. Wersja VirtualBoxa ---
RAW_VER="$($VBOXM -v)"          # np. 7.2.2r162584
VB_VER="${RAW_VER%%r*}"         # wycina wszystko po 'r' → 7.2.2

if [[ -z "$VB_VER" ]]; then
    err "Nie udało się odczytać wersji VirtualBoxa z: $RAW_VER"
    exit 1
fi

info "Wykryta wersja VirtualBox: $VB_VER"

# --- 3. Aktualny Extension Pack ---
EP_VER=""
EP_USABLE="false"

if "$VBOXM" list extpacks | grep -q "^Extension Packs:"; then
    EP_VER=$("$VBOXM" list extpacks | awk '/Version:/ {print $2; exit}')
    EP_USABLE=$("$VBOXM" list extpacks | awk '/Usable:/ {print $2; exit}')
fi

if [[ -n "$EP_VER" ]]; then
    info "Znaleziony Extension Pack: wersja $EP_VER (usable: $EP_USABLE)"
else
    info "Brak zainstalowanego Extension Packa."
fi

# --- 4. Jeśli już jest OK, kończymy ---
if [[ "$EP_VER" == "$VB_VER" && "$EP_USABLE" == "true" ]]; then
    ok "Extension Pack już pasuje do VirtualBoxa ($VB_VER). Nic nie robię."
    exit 0
fi

# --- 5. Trzeba doinstalować / podmienić ---
EP_NAME="Oracle_VM_VirtualBox_Extension_Pack-${VB_VER}.vbox-extpack"
EP_URL="https://download.virtualbox.org/virtualbox/${VB_VER}/${EP_NAME}"
EP_TMP="/tmp/${EP_NAME}"

info "Przygotowanie do instalacji/podmiany Extension Packa na wersję: $VB_VER"
info "URL: $EP_URL"

# --- 6. Pobieranie ---
if [[ -f "$EP_TMP" ]]; then
    info "Plik już istnieje w /tmp, używam: $EP_TMP"
else
    if command -v wget >/dev/null 2>&1; then
        info "Pobieram przez wget..."
        wget -q --show-progress -O "$EP_TMP" "$EP_URL" || {
            err "Błąd pobierania z $EP_URL"
            exit 1
        }
    elif command -v curl >/dev/null 2>&1; then
        info "Pobieram przez curl..."
        curl -L "$EP_URL" -o "$EP_TMP" || {
            err "Błąd pobierania z $EP_URL"
            exit 1
        }
    else
        err "Brak wget/curl. Zainstaluj jedno z nich i odpal ponownie."
        exit 1
    fi
fi

# --- 7. Instalacja / podmiana ---
info "Instaluję Extension Pack (może wymagać hasła sudo)..."

# Jeśli był, usuwamy głównego, ale VBoxManage --replace zwykle wystarcza.
# Zostawiamy inteligentnie:
sudo "$VBOXM" extpack install --replace "$EP_TMP" <<EOF
y
EOF

# --- 8. Weryfikacja ---
NEW_VER=$("$VBOXM" list extpacks | awk '/Version:/ {print $2; exit}')
NEW_USABLE=$("$VBOXM" list extpacks | awk '/Usable:/ {print $2; exit}')

if [[ "$NEW_VER" == "$VB_VER" && "$NEW_USABLE" == "true" ]]; then
    ok "Extension Pack zsynchronizowany: $NEW_VER (usable: $NEW_USABLE)"
    ok "VirtualBox + ExtPack w tej samej wersji = full moc, zero clashy."
    exit 0
else
    err "Coś nie pykło. Aktualnie:"
    "$VBOXM" list extpacks || true
    exit 1
fi

