#!/bin/bash

echo "🔥 Dodawanie repozytorium Chaotic-AUR..."

# Pobranie i dodanie klucza
sudo pacman-key --recv-key 3056513887B78AEB --keyserver keyserver.ubuntu.com
sudo pacman-key --lsign-key 3056513887B78AEB

# Pobranie kluczy i mirrorlist
cd /tmp
wget https://cdn.chaotic.cx/chaotic-aur/chaotic-keyring.pkg.tar.zst
wget https://cdn.chaotic.cx/chaotic-aur/chaotic-mirrorlist.pkg.tar.zst

sudo pacman -U chaotic-keyring.pkg.tar.zst chaotic-mirrorlist.pkg.tar.zst --noconfirm

# Dodanie do pacman.conf jeśli nie istnieje
if ! grep -q "\[chaotic-aur\]" /etc/pacman.conf; then
    echo -e "\n[chaotic-aur]\nInclude = /etc/pacman.d/chaotic-mirrorlist" | sudo tee -a /etc/pacman.conf
fi

# Aktualizacja pacman
sudo pacman -Sy

# Instalacja Compiza i dodatków
sudo pacman -S compiz compiz-plugins-main compiz-plugins-extra compizconfig-settings-manager fusion-icon --noconfirm

echo "✅ Gotowe! Uruchom Compiza:"
echo "→ fusion-icon &"
echo "→ albo compiz --replace &"

