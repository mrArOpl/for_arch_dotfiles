#!/bin/bash
#
# as ver. 0.1  -> _vusb.sh
#
# USBVHDX='usb.vmdk'
echo ' Login user: '$USER
echo ' Create usb.vmdk - file  - mirror disk (bootusb, ventoy) after booting in VirtualBox'
echo ' Choice disk  for create usb.vmdk (sda, sdb, sdc, sdx...) '
lsblk -f
echo ' Podaj dysk:  sdx '
read  USBDISK
echo ' Uwaga buduję plik usb.vmdk , wybrany dysk :  /dev/'$USBDISK
echo ' Podaj nazwę usb, można kilka utworzyć (usbx.vmdk)'
read USBVHDX
# sudo vboxmanage internalcommands createmedium -filename /home/as/$USBVHDX -rawdisk /dev/$USBDISK
sudo vboxmanage internalcommands createrawvmdk -filename /home/as/$USBVHDX -rawdisk /dev/$USBDISK
sudo chown as:as /home/as/$USBVHDX
echo 'GOTOWE,  ok?'
ls -al /home/as/$USBVHDX
# sudo usermod -a -G disk anty
# sudo usermod -a -G vboxusers anty
#
## ArO(c)2023
