#!/bin/bash
# Mount vol. in the VeraCrypt
# ArO(c)2021
clear
echo ' '
echo '___________________________________'
echo ' ArO(c)2021 - Mount VeraCrypt all '
echo '___________________________________'
echo ' '
veracrypt /dev/nvme0n1p5 /media/veracrypt7
cd /media/veracrypt7
ls
veracrypt /media/anty/100GB/_5_win_best.hc /media/veracrypt2 
veracrypt /media/anty/100GB/_5_G_B1_pass_and_info.hc /media/veracrypt5
veracrypt /media/anty/100GB/_6_act_pass_key_vpn.hc /media/veracrypt1
echo '___________________________________'
echo ' veracrypt mounted vc7-112Gb and vc1, vc2, vc5 from files - ArO '
echo ' '
