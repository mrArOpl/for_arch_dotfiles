#!/bin/bash
###########
#
#  sudo bash manjaro_install.sh  
#  greate etitors: geany, pluma, mousepad
#
#  Made by ArO from POLAND, contact: mail: dr.code@tuta.io and hack.pegasus@protonmail.com
#                                    session: alan555.pl
#
###
clear
echo ' Manjaro install soft (c)2024 ArO '
echo ' Please before update and upgrade linux... '
pacman -Sy
pacman -S net-tools speedtes-cli
# pacman -S doublecmd-gtk2     # copy .config/ and download portable
# pacman -S terminator tilix   # copy .config/
pacman -S tilda terminology
pacman -S bluefish
pacman -S partitiomanager
pacman -S xpdf atril evince okular xreader
pacman -S mc bleachbit whois
pacman -S pluma gedit geany
pacman -S mtr iftop
pacman -S bitwarden
pacman -S vokoscreen ristretto krita pinta mat2
pacman -S seahorse
pacman -S nmap vulscan
pacman -S pitivi obs-studio
pacman -S smplayer parole vlc
# pacman -S guvcview movit motion tvtime wire-desktop srs openshot nageru openshot baresip avidemux-qt gnome-video-effects cheese flowblade kdenlive
pacman -S hplip
pacman -S composer
pacman -S abiword
# pacman -S neofetch cpufetch fastfetch onefetch screenfetch uwufetch
pacman -S figlet toilet beep
# pacman -S dnscrypt-proxy dnscrypt-wrapper
# pacman -S libredefender
pacman -S yt-dlp ytfzf
pacman -S pv
pacman -S epiphany netsurf pix pkgbrowser
pacman -S qbittorrent
# pacman -S pdfcrack xreader zsh-doc mupdf-gl mupdf-tools texworks gscan2pdf pdfslicer pdfmixtool
# pacman -S phpldapadmin
pacman -S python-pip python-xyz python-pipx
pacman -S scrcpy apksigcopier
pacman -S vinagre tigervnc gtk-vnc
pacman -S remmina krdc
pacman -S fuseiso brasero
pacman -S eza # fork exa
# install from menu virtualbox(guest,iso,ext.,mod) & virtmanager
# firewall allow ports: 5555 , 5900
# check net: netstat -tuae(n)
# disable avahi: systemctl stop avahi-daemon.service
#
echo ' '
echo ' Manjaro install soft (c)2024.10 ArO -------->  END   <---------- '
###
#############################################################################################################################################################
