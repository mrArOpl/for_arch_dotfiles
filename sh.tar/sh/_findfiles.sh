#!/bin/bash
# Skrypt pyta użytkownika o nazwę pliku, sprawdza,
# czy nazwa nie jest pusta ani składająca się wyłącznie ze spacji,
# a następnie wyszukuje pliki o tej nazwie zaczynając od katalogu root (/).
# Wyniki zapisuje w pliku:   "wynik.txt".

# Pytanie o nazwę pliku
echo -n "Podaj nazwę pliku: "
read filename

# Sprawdzenie, czy nazwa pliku jest pusta lub zawiera tylko spacje
if [[ -z "${filename// /}" ]]; then
    echo "Błąd: Należy wprowadzić poprawną nazwę pliku zawierającą znaki."
    exit 1
fi

# Plik wynikowy
output_file="wynik.txt"

# Wyszukiwanie plików i zapisywanie wyników
find / -type f -name "$filename" 2>/dev/null > "$output_file"

echo "Wyniki zapisano w pliku: $output_file"

