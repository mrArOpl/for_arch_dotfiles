#!/bin/bash
# _wifi_recon_suite.sh – full recon + detekcja + logi
# ArO + ChatGPT OG Style

export_dir="/tmp/wifi_recon"
iface="wlan0"
subnet="192.168.1.0/24"
moniface="wlan0mon"
logfile="$export_dir/recon_log.txt"

mkdir -p "$export_dir"
echo -e "\n[+] OG Recon start: $(date)" | tee -a "$logfile"

# MAC + Hostname spoof
echo "[+] MAC/hostname randomizacja..."
sudo ip link set $iface down
sudo macchanger -r $iface
sudo hostnamectl set-hostname reconbox-$(shuf -i 1000-9999 -n 1)
sudo ip link set $iface up

# Host scan
echo "[+] Skanuję sieć..."
sudo nmap -sn -T2 $subnet -oN "$export_dir/hosts.txt"
cat "$export_dir/hosts.txt" >> "$logfile"

# Sniff DHCP/ARP
echo "[+] Sniff 30s (ARP/DHCP)..."
sudo timeout 30s tcpdump -i $iface arp or port 67 or port 68 -w "$export_dir/sniff.pcap"

# DNS/SSL detekcja
echo "[+] Uruchamiam rogue_ap_detector..."
bash ./_rogue_ap_detector.sh >> "$logfile"

# Wylistuj wszystko
echo "[✓] Zakończono. Logi w: $export_dir"
ls -lh "$export_dir"
# OPIS:
#  Idealne do:
#  rozpoznania dziwnej sieci,
#
#  zebrania dowodów na honeypot,
#
#  działania bez internetu.

