#!/bin/bash

# CPU Benchmark
sysbench --test=cpu --cpu-max-prime=150000 run
sysbench --test=cpu --cpu-max-prime=15000 run --num-threads=4

#FILE IO Benchmark
sysbench --test=fileio --file-total-size=1G --file-test-mode=seqwr run
sysbench --test=fileio --file-total-size=1G cleanup

#MEMROY Benchmark
sysbench --test=memory --memory-block-size=1M --memory-total-size=8G run

