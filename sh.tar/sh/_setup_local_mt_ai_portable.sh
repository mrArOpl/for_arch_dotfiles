#!/usr/bin/env bash
# _setup_local_mt_ai_portable.sh
set -euo pipefail

DIR="${1:-ArO_local_mt}"
mkdir -p "$DIR"
cd "$DIR"

python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip

# CPU-only (bez CUDA): spokojnie działa na Manjaro/Arch
python -m pip install "transformers>=4.40" "sentencepiece" "sacremoses" "torch"

echo "[✓] venv gotowy: $DIR"
echo "Aktywacja: source $DIR/.venv/bin/activate"

