#!/bin/bash

# OG mat2 cleaner PRO by ArO + AI
# Rekurencyjne czyszczenie metadanych z plików obsługiwanych przez mat2
# Obsługuje tryby: all, only-images, only-docs, dry-run, list

TARGET="."
MODE="all"
DRYRUN=0
LISTONLY=0
LOG="mat2_errors.log"

# --- Wzorce plików ---
IMG_EXT="\( -iname '*.jpg' -o -iname '*.jpeg' -o -iname '*.png' -o -iname '*.tif' -o -iname '*.tiff' -o -iname '*.webp' \)"
DOC_EXT="\( -iname '*.pdf' -o -iname '*.docx' -o -iname '*.xlsx' -o -iname '*.pptx' -o -iname '*.odt' -o -iname '*.odp' -o -iname '*.ods' \)"

show_help() {
    echo "Użycie: $0 [opcje] [katalog]"
    echo ""
    echo "Opcje:"
    echo "  --all            - czyść wszystkie obsługiwane pliki (domyślnie)"
    echo "  --only-images    - tylko grafiki"
    echo "  --only-docs      - tylko dokumenty"
    echo "  --dry-run        - pokazuje co by zrobił, bez zmian"
    echo "  --list           - tylko wypisz pliki, bez czyszczenia"
    echo "  --help           - ta pomoc"
    exit 0
}

# --- Parsowanie argumentów ---
for arg in "$@"; do
    case "$arg" in
        --all) MODE="all" ;;
        --only-images) MODE="img" ;;
        --only-docs) MODE="doc" ;;
        --dry-run) DRYRUN=1 ;;
        --list) LISTONLY=1 ;;
        --help) show_help ;;
        *) TARGET="$arg" ;;
    esac
done

# --- Wybor filtrów ---
case "$MODE" in
    all) FIND_FILTER="-type f" ;;
    img) FIND_FILTER="-type f $IMG_EXT" ;;
    doc) FIND_FILTER="-type f $DOC_EXT" ;;
esac

echo "[*] Tryb: $MODE"
echo "[*] Katalog: $TARGET"
echo "[*] Log błędów: $LOG"
echo "" > "$LOG"

echo ""
echo "[*] Szukam plików…"

FILES=$(eval find "\"$TARGET\"" $FIND_FILTER -print0)

# Jeśli --list
if [[ $LISTONLY -eq 1 ]]; then
    echo "[*] Lista plików do czyszczenia:"
    printf "%s" "$FILES" | tr '\0' '\n'
    exit 0
fi

# Jeśli dry-run
if [[ $DRYRUN -eq 1 ]]; then
    echo "[*] DRY RUN — nic nie modyfikuję."
    printf "%s" "$FILES" | tr '\0' '\n'
    exit 0
fi

# --- Główna akcja ---
printf "%s" "$FILES" | \
xargs -0 -I{} sh -c '
    echo ">> Czyszczę: {}"
    mat2 --inplace "{}" 2>>"'"$LOG"'"
'

echo ""
echo "[✓] Zakończone! Jeśli log '$LOG' jest pusty → wszystko poszło gładko."

