cat page.html \
 | python 03_extract_main_only.py \
 | libretranslate-cli --html \
 > page_pl.html

