#!/bin/bash
# _vm_switcher.sh – OG Virtualization Switcher by ArO + AI
# Przełącza aktywne środowisko wirtualizacji (VirtualBox <-> KVM/VirtManager)
# Działa na Manjaro/Arch, wymaga sudo do modprobe.

# Kolory dla czytelności
RED="\e[31m"; GREEN="\e[32m"; YELLOW="\e[33m"; BLUE="\e[34m"; RESET="\e[0m"

# Sprawdź, co jest aktualnie aktywne
active_env="none"
if lsmod | grep -q vboxdrv; then
    active_env="virtualbox"
elif lsmod | grep -q kvm; then
    active_env="kvm"
fi

echo -e "${YELLOW}=== VM Switcher by ArO + AI ===${RESET}"
echo -e "Aktualnie aktywny: ${GREEN}${active_env}${RESET}\n"

echo "Co chcesz aktywować?"
echo "  1) VirtualBox"
echo "  2) KVM / Virt-Manager"
echo -n "Wybierz [1-2]: "
read -r choice

case "$choice" in
    1)
        echo -e "${BLUE}Wyłączam KVM i włączam VirtualBox...${RESET}"
        sudo modprobe -r kvm_intel kvm_amd kvm 2>/dev/null
        sudo modprobe -r vboxdrv vboxnetflt vboxnetadp 2>/dev/null
        sudo modprobe vboxdrv
        if lsmod | grep -q vboxdrv; then
            echo -e "${GREEN}VirtualBox aktywny.${RESET}"
        else
            echo -e "${RED}Błąd: nie udało się załadować modułu vboxdrv.${RESET}"
        fi
        ;;
    2)
        echo -e "${BLUE}Wyłączam VirtualBox i włączam KVM...${RESET}"
        sudo modprobe -r vboxdrv vboxnetflt vboxnetadp 2>/dev/null
        if grep -q Intel /proc/cpuinfo; then
            sudo modprobe kvm_intel
        else
            sudo modprobe kvm_amd
        fi
        sudo modprobe kvm
        if lsmod | grep -q kvm; then
            echo -e "${GREEN}KVM / Virt-Manager aktywny.${RESET}"
        else
            echo -e "${RED}Błąd: nie udało się załadować modułów KVM.${RESET}"
        fi
        ;;
    *)
        echo -e "${RED}Nieprawidłowy wybór.${RESET}"
        ;;
esac

echo -e "\n${YELLOW}Stan po operacji:${RESET}"
lsmod | egrep 'vbox|kvm' || echo "(brak aktywnych modułów)"
echo -e "${YELLOW}==============================${RESET}"

