#!/bin/bash
# ArO edition – SSH Defense Pack: opóźnienie + fail2ban + banner
# Tested on Debian 11/12 (powinien też śmigać na Kali/ParrotOS)

set -e

# Ustawienia
DELAY_MICROSEC=7000000   # 7 sekund opóźnienia
F2B_BANTIME=3600         # 1h ban
F2B_MAXRETRY=3
F2B_FINDTIME=600         # 10 min
BANNER_MSG="Unauthorized access is logged and will be reported."

echo "[+] Instalacja zależności..."
apt update
apt install -y fail2ban

echo "[+] Konfiguracja opóźnienia logowania (PAM)..."
PAM_SSHD="/etc/pam.d/sshd"
if ! grep -q pam_faildelay "$PAM_SSHD"; then
    sed -i "1i auth optional pam_faildelay.so delay=$DELAY_MICROSEC" "$PAM_SSHD"
    echo "[*] Dodano pam_faildelay.so z opóźnieniem ${DELAY_MICROSEC}µs"
else
    echo "[!] pam_faildelay już skonfigurowany – pomijam"
fi

echo "[+] Konfiguracja Fail2Ban..."
F2B_JAIL="/etc/fail2ban/jail.local"
cp /etc/fail2ban/jail.conf "$F2B_JAIL"

cat >> "$F2B_JAIL" <<EOF

[sshd]
enabled = true
port    = ssh
filter  = sshd
logpath = /var/log/auth.log
maxretry = $F2B_MAXRETRY
bantime = $F2B_BANTIME
findtime = $F2B_FINDTIME
EOF

echo "[+] Konfiguracja bannera SSH..."
echo "$BANNER_MSG" > /etc/issue.net
sed -i '/^#Banner/s/^#//' /etc/ssh/sshd_config
sed -i '/^Banner/c\Banner /etc/issue.net' /etc/ssh/sshd_config

echo "[+] Restart usług..."
systemctl restart sshd
systemctl enable --now fail2ban

echo -e "\n✅ Gotowe! System chroniony:"
echo "• pam_faildelay: $(($DELAY_MICROSEC/1000000))s opóźnienia"
echo "• Fail2Ban: ban po $F2B_MAXRETRY próbach (na $F2B_BANTIME sek)"
echo "• Banner ustawiony"
echo -e "\nSprawdź status: \e[32mfail2ban-client status sshd\e[0m"

