#!/usr/bin/env bash
# _pdf2pl_ai_local.sh
set -euo pipefail

IN="${1:?Podaj input.pdf}"
OUT="${2:-$(basename "${IN%.*}")_PL}"
ENGINE="${3:-marian}"   # marian | m2m100 | nllb

command -v pdftotext >/dev/null || { echo "Brak pdftotext (poppler)"; exit 1; }
command -v python >/dev/null || { echo "Brak python"; exit 1; }

TMP="$(mktemp -d)"; trap 'rm -rf "$TMP"' EXIT
pdftotext "$IN" "$TMP/in.txt"

python _ai_translate_txt.py --engine "$ENGINE" --src en --tgt pl \
  --infile "$TMP/in.txt" --outfile "${OUT}.pl.txt"

echo "[✓] TXT: ${OUT}.pl.txt"

# opcjonalnie PDF
if command -v pandoc >/dev/null; then
  pandoc "${OUT}.pl.txt" -o "${OUT}.pl.pdf" >/dev/null 2>&1 || true
  [[ -f "${OUT}.pl.pdf" ]] && echo "[✓] PDF: ${OUT}.pl.pdf"
fi

