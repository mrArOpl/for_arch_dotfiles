#!/bin/bash

# Nazwa pliku kopii
BACKUP_FILE="$1"

if [ -z "$BACKUP_FILE" ]; then
    echo "❌ Użycie: ./restore_mate.sh nazwa_pliku.zip"
    exit 1
fi

if [ ! -f "$BACKUP_FILE" ]; then
    echo "❌ Plik $BACKUP_FILE nie istnieje!"
    exit 1
fi

echo "♻️ Przywracam ustawienia z $BACKUP_FILE..."

unzip -o "$BACKUP_FILE" -d ~/

echo "✅ Przywracanie zakończone!"

echo "🔄 Zrestartuj sesję graficzną lub uruchom ponownie komputer, aby zastosować zmiany."

