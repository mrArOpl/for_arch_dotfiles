#!/bin/bash

PLIK_IP="adresyip.txt"
PLIK_WYNIK="wyniki_index.txt"

echo "[*] Start skanowania hostów z pliku $PLIK_IP"

# Wyczyść poprzedni wynik
> "$PLIK_WYNIK"

while IFS= read -r ip; do
    echo "[*] Skanuję: $ip"
    wynik=$(nmap -p 80 --script http-title "$ip" | grep "Index of")

    if [[ ! -z "$wynik" ]]; then
        echo "[+] Znaleziono otwarty indeks na: $ip"
        echo "$ip - $wynik" >> "$PLIK_WYNIK"
    fi
done < "$PLIK_IP"

echo "[✓] Skanowanie zakończone. Wyniki zapisano w pliku $PLIK_WYNIK"

