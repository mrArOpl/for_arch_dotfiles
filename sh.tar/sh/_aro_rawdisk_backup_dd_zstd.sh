#!/usr/bin/env bash
# _aro_rawdisk_backup_dd_zstd.sh
# Autor: ArO + AI
# Opis:
#   RAW sektor-by-sektor backup całego dysku (np. /dev/nvme0n1),
#   skompresowany zstd, z pv (progres), logiem i checksum SHA256.
#
# Uwaga:
#   TO JEST PEŁNY OBRAZ DYSKU – MBR/GPT, EFI, LUKS, BitLocker, FileVault itd.
#   Idealne do zaszyfrowanych systemów, multi-boot i dysków startowych.

set -euo pipefail

usage() {
    cat <<EOF
Użycie:
  sudo $0 /dev/SDX [katalog_docelowy]

Przykłady:
  sudo $0 /dev/nvme0n1 /mnt/backup
  sudo $0 /dev/sda

Jeśli katalog_docelowy nie zostanie podany, użyty będzie katalog bieżący.

Output (w katalogu docelowym):
  <dev>_raw_YYYY-MM-DD_HH-MM.dd.zst
  <dev>_raw_YYYY-MM-DD_HH-MM.log
  <dev>_raw_YYYY-MM-DD_HH-MM.sha256

Przykład:
  nvme0n1_raw_2025-12-12_01-23.dd.zst
  nvme0n1_raw_2025-12-12_01-23.log
  nvme0n1_raw_2025-12-12_01-23.sha256
EOF
    exit 1
}

# --- sprawdzenie roota ---
if [[ "${EUID}" -ne 0 ]]; then
    echo "⚠ Ten skrypt musi działać jako root (sudo)."
    exit 1
fi

# --- argumenty ---
if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage
fi

DISK_DEV="$1"
DEST_DIR="${2:-$(pwd)}"

# --- walidacja urządzenia ---
if [[ ! -b "${DISK_DEV}" ]]; then
    echo "❌ ${DISK_DEV} nie jest blokowym urządzeniem (np. /dev/sda, /dev/nvme0n1)."
    exit 1
fi

# sprawdź, czy to dysk, a nie pojedyncza partycja (opcjonalnie)
TYPE="$(lsblk -no TYPE "${DISK_DEV}" | head -n1 || true)"
if [[ "${TYPE}" != "disk" ]]; then
    echo "⚠ Uwaga: ${DISK_DEV} nie jest typu 'disk' (tylko '${TYPE}')."
    echo "   Skrypt jest projektowany głównie pod pełne dyski, ale poleci też na partycji."
    read -rp "Kontynuować mimo to? [tak/N]: " cont_type
    cont_type="${cont_type,,}"
    if [[ "${cont_type}" != "tak" && "${cont_type}" != "t" && "${cont_type}" != "y" ]]; then
        echo "Przerwano przez użytkownika."
        exit 1
    fi
fi

# --- sprawdzenie zależności ---
for bin in dd pv zstd lsblk blockdev sha256sum; do
    if ! command -v "$bin" &>/dev/null; then
        echo "❌ Brak programu: $bin  (zainstaluj, np.: sudo pacman -S $bin lub sudo apt install $bin)"
        exit 1
    fi
done

mkdir -p "${DEST_DIR}"

# --- info o dysku ---
DISK_NAME="$(basename "${DISK_DEV}")"

# rozmiar w bajtach – dla pv
DISK_SIZE_BYTES="$(blockdev --getsize64 "${DISK_DEV}")"
# ładny rozmiar
DISK_SIZE_HUMAN="$(lsblk -bdno SIZE "${DISK_DEV}" 2>/dev/null || echo "${DISK_SIZE_BYTES}")"

TS="$(date +%F_%H-%M)"
OUT_PREFIX="${DISK_NAME}_raw_${TS}"
OUT_IMG="${DEST_DIR}/${OUT_PREFIX}.dd.zst"
LOG_FILE="${DEST_DIR}/${OUT_PREFIX}.log"
SUM_FILE="${DEST_DIR}/${OUT_PREFIX}.sha256"

echo "=== ArO + AI RAW DISK BACKUP (sector-by-sector) ==="
echo "Dysk źródłowy : ${DISK_DEV}"
echo "Nazwa         : ${DISK_NAME}"
echo "Rozmiar       : ${DISK_SIZE_HUMAN} (bajty: ${DISK_SIZE_BYTES})"
echo "Katalog docel.: ${DEST_DIR}"
echo "Plik obrazu   : ${OUT_IMG}"
echo "Log           : ${LOG_FILE}"
echo "Checksum      : ${SUM_FILE}"
echo "---------------------------------------------------"

echo "⚠ UWAGA OG:"
echo "  • To jest PEŁNY obraz dysku – nadpisanie przy restore wyczyści wszystko."
echo "  • Idealnie robić backup z innego systemu/live-USB (nie z dysku, który backupujesz)."
echo

read -rp "Na pewno robić backup tego dysku? [tak/N]: " yn
yn="${yn,,}"
if [[ "${yn}" != "tak" && "${yn}" != "t" && "${yn}" != "y" ]]; then
    echo "Przerwano przez użytkownika."
    exit 1
fi

echo ">>> Start backupu: $(date)" | tee "${LOG_FILE}"
echo "Polecenie: dd | pv | zstd" | tee -a "${LOG_FILE}"

# --- właściwy backup: dd -> pv -> zstd ---
# dd:   conv=sync,noerror – kontynuuj przy błędach, wypełnia zerami
# pv:   -s ROZMIAR – ładny progress bar
# zstd: -T0 – wszystkie rdzenie, -19 – mocna kompresja
set -o pipefail
if dd if="${DISK_DEV}" bs=64K conv=sync,noerror status=none 2>>"${LOG_FILE}" \
    | pv -s "${DISK_SIZE_BYTES}" \
    | zstd -T0 -19 -o "${OUT_IMG}" >>"${LOG_FILE}" 2>&1; then

    echo ">>> Backup zakończony OK: $(date)" | tee -a "${LOG_FILE}"
else
    echo "❌ Błąd podczas backupu – sprawdź log: ${LOG_FILE}"
    exit 1
fi

# --- checksum ---
echo ">>> Liczę SHA256 pliku ${OUT_IMG}..." | tee -a "${LOG_FILE}"
if sha256sum "${OUT_IMG}" | tee "${SUM_FILE}" >>"${LOG_FILE}" 2>&1; then
    echo ">>> SHA256 zapisany w: ${SUM_FILE}" | tee -a "${LOG_FILE}"
else
    echo "⚠ Nie udało się policzyć SHA256 – sprawdź ręcznie." | tee -a "${LOG_FILE}"
fi

echo "=== ZAKOŃCZONE ==="
echo "Plik obrazu : ${OUT_IMG}"
echo "Log         : ${LOG_FILE}"
echo "SHA256      : ${SUM_FILE}"
echo "Trzymaj to w bezpiecznym miejscu, OG. 💾"

