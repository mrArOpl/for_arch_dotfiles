#!/bin/bash
#              --> ArO (c)2021.11 <--
#
#  _firewall 
#
#  sudo cp _firewall /etc/init.d/                     --> autostart
#  sudo update-rc.d _firewall defaults 90
#
#  sudo /etc/init.d/_firewall stop                   --> stop
#  
#  sudo /etc/init.d/_firewall                           --> start  
#
#  ShieldsUP!  https://www.grc.com/x/ne.dll?bh0bkyd2  scan all ports
#
#  Uwaga ! Warsja rozwojowa. Ustawienia dla ip4. Wymagane uprawnienia root (sudo _firewall).
#
#  czyszczenie iptables:

# reset
clear 

iptables -F
iptables -Z
iptables -X
iptables -F -t nat
iptables -X -t nat
iptables -Z -t nat
iptables -F -t filter
iptables -X -t filter
iptables -Z -t filter
iptables -F -t mangle
iptables -X -t mangle
iptables -Z -t mangle

# ustalamy domy�ln� polityk� dla filtr�w

iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# iptables -A OUTPUT -p tcp --dport 1024:6999 -j DROP
iptables -A OUTPUT -p tcp --dport 80 -j DROP                       # Po��czenia nieszyfrowane http

# pe�ny ruch na interfejsie lo (potrzebne do dzia�ania wielu lokalnych us�ug)

iptables -A INPUT -i lo -j ACCEPT

# odrzucamy pakiety dla port�w Microsoft i netBios
iptables -A INPUT -p tcp --dport 631 -j DROP            # ipp
iptables -A OUTPUT -p tcp --dport 631 -j DROP
iptables -A INPUT -p tcp --dport 137 -j DROP
iptables -A OUTPUT -p tcp --dport 137 -j DROP
iptables -A INPUT -p tcp --dport 137 -j DROP
iptables -A OUTPUT -p tcp --dport 138 -j DROP
iptables -A INPUT -p tcp --dport 139 -j DROP
iptables -A OUTPUT -p tcp --dport 139 -j DROP
iptables -A INPUT -p tcp --dport 445 -j DROP
iptables -A OUTPUT -p tcp --dport 445 -j DROP
iptables -A INPUT -p tcp --dport 113 -j REJECT --reject-with icmp-port-unreachable
iptables -A OUTPUT -p tcp --dport 113 -j REJECT --reject-with icmp-port-unreachable

# ochrona przed atakami

iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s -j LOG --log-prefix "Ping: "
iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s -j ACCEPT # Ping of death

# iptables -A INPUT -p icmp --icmp-type echo-request -j REJECT --reject-with icmp-host-unreachable

iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH ACK -j LOG --log-prefix "ACK scan: "
iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH ACK -j DROP # Metoda ACK (nmap -sA)
iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH FIN -j LOG --log-prefix "FIN scan: "
iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH FIN -j DROP # Skanowanie FIN (nmap -sF)
iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH PSH -j LOG --log-prefix "Xmas scan: "
iptables -A INPUT -m conntrack --ctstate NEW -p tcp --tcp-flags SYN,RST,ACK,FIN,URG,PSH FIN,URG,PSH -j DROP # Metoda Xmas Tree (nmap -sX)
iptables -A INPUT -m conntrack --ctstate INVALID -p tcp ! --tcp-flags SYN,RST,ACK,FIN,PSH,URG SYN,RST,ACK,FIN,PSH,URG -j LOG --log
iptables -A INPUT -m conntrack --ctstate INVALID -p tcp ! --tcp-flags SYN,RST,ACK,FIN,PSH,URG SYN,RST,ACK,FIN,PSH,URG -j DROP # Skanowanie Null (nmap -sN)

# �a�cuch syn-flood (obrona przed DoS)

iptables -N syn-flood
iptables -A INPUT -p tcp --syn -j syn-flood
iptables -A syn-flood -m limit --limit 1/s --limit-burst 4 -j RETURN
iptables -A syn-flood -m limit --limit 1/s --limit-burst 4 -j LOG --log-prefix "SYN-flood: "
iptables -A syn-flood -j DROP

# pozwalamy na wszystkie istniej�ce ju� po��czenia oraz po��czenia kt�re s� powi�zane z istniej�cymi ju� po��czeniami

iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# iptables -A INPUT -m state --state NEW -p tcp --dport 22 --source 192.168.1.144/24 -j ACCEPT

# ca�y ruch powy�ej port�w 1024, to s� porty kt�re mog� by� bindowane przez wszystko (chocia�by np. Kadu)

# iptables -A INPUT -m state --state NEW -p tcp --dport 1024:65535 -j ACCEPT
# iptables -A INPUT -m state --state NEW -p udp --dport 1024:65535 -j ACCEPT

# uruchomione serwery na portach poni�ej 1024: ssh, http, https
# iptables -A INPUT -m state --state NEW -m multiport -p tcp --dports 22,80 -j ACCEPT
# Samba
# iptables -A INPUT -m state --state NEW -m multiport -p udp --dports 137,138 --source 192.168.1.0/24 -j ACCEPT
# iptables -A INPUT -m state --state NEW -m multiport -p tcp --dports 139,445 --source 192.168.1.0/24 -j ACCEPT
#

# Wy�wietlenie ustawionych regu� iptables ip4
iptables -S

#
# as (c)2021 https://aro.5v.pl
