#!/bin/bash
# _scanner_suite_OG.sh
# OG scanner: Bluetooth + LAN/MAC
# Export results to txt
# Autor: ArO & AI
# Data: 2025-08-19

clear
echo "===================================="
echo "      OG Scanner Suite v1.0"
echo "      Bluetooth + LAN/MAC"
echo "===================================="

# ===== Funkcja Bluetooth =====
bluetooth_scan() {
    echo "[*] Sprawdzam dostępne urządzenia Bluetooth..."
    OUTPUT_FILE="bluetooth_scan.txt"
    echo "Bluetooth Scan - $(date)" > "$OUTPUT_FILE"

    # Włączamy interfejs i scan
    echo "[*] Uruchamiam bluetoothctl..."
    sudo bluetoothctl << EOF > temp_bt_scan.txt
scan on
EOF

    # Pobranie wyników (ostatnie 30 linii, bo bluetoothctl leci non-stop)
    tail -n 30 temp_bt_scan.txt >> "$OUTPUT_FILE"
    rm temp_bt_scan.txt

    echo "[*] Wyniki zapisane w $OUTPUT_FILE"
    echo
}

# ===== Funkcja LAN/MAC =====
lan_mac_scan() {
    echo "[*] Skanuję sieć LAN po MAC/IP..."
    OUTPUT_FILE="lan_mac_scan.txt"
    echo "LAN/MAC Scan - $(date)" > "$OUTPUT_FILE"

    # Wykrywanie interfejsu
    INTERFACE=$(ip route | grep '^default' | awk '{print $5}')
    echo "[*] Używam interfejsu: $INTERFACE"

    # ARP-scan (szybki i OG)
    echo "[*] Uruchamiam arp-scan..."
    sudo arp-scan --interface="$INTERFACE" --localnet >> "$OUTPUT_FILE" 2>/dev/null

    # nmap scan tylko dla tych w LAN
    echo "[*] Uruchamiam nmap ping scan..."
    IP_RANGE=$(ip -o -f inet addr show $INTERFACE | awk '{print $4}')
    sudo nmap -sn "$IP_RANGE" >> "$OUTPUT_FILE" 2>/dev/null

    echo "[*] Wyniki zapisane w $OUTPUT_FILE"
    echo
}

# ===== Menu OG =====
while true; do
    echo "Wybierz opcję:"
    echo "1) Bluetooth Scan"
    echo "2) LAN/MAC Scan"
    echo "3) Oba (Bluetooth + LAN/MAC)"
    echo "4) Wyjście"
    read -rp "Twój wybór: " choice

    case $choice in
        1)
            bluetooth_scan
            ;;
        2)
            lan_mac_scan
            ;;
        3)
            bluetooth_scan
            lan_mac_scan
            ;;
        4)
            echo "[*] Kończę działanie, OG style."
            exit 0
            ;;
        *)
            echo "[!] Nieprawidłowy wybór, spróbuj ponownie."
            ;;
    esac
done

