#!/bin/bash
#
# ArO (c)2024 Reset & Install Arch Repo Keys..
#             Use sudo or root: sudo ./_keytocos.sh
#
sudo pacman -Sy
sudo rm -r /etc/pacman.d/gnupg
sudo pacman-key --init
sudo pacman-key --populate archlinux cachyos
sudo pacman-key --refresh-keys


