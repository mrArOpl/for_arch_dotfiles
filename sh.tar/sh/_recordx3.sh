# Ekran + system audio + mikrofon osobno
ffmpeg -video_size 1920x1080 -framerate 30 -f x11grab -i :0.0 \
-f pulse -i default -c:v libx264 ekran.mp4 \
-f pulse -i alsa_input.pci-0000_00_1b.0.analog-stereo mic.wav

