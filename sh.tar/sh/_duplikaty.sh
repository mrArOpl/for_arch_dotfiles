#!/bin/bash
#
#
# Oto skrypt w Bash, który rekurencyjnie przeszukuje katalog w poszukiwaniu plików o identycznych nazwach
# i zapisuje ich pełne ścieżki do pliku duplikaty.txt.
#
# Find Duplicate Files
# Sprawdzamy, czy podano katalog jako argument
if [ -z "$1" ]; then
    echo "Użycie: $0 <ścieżka_do_katalogu>"
    exit 1
fi

# Katalog do przeszukania
SEARCH_DIR="$1"
OUTPUT_FILE="duplikaty.txt"

# Czyszczenie pliku wyjściowego
> "$OUTPUT_FILE"

# Znajdowanie wszystkich plików i sortowanie po nazwie
find "$SEARCH_DIR" -type f | awk -F/ '{print $NF, $0}' | sort | uniq -D -w50 | awk '{print $2}' > "$OUTPUT_FILE"

# Wyświetlenie wyniku użytkownikowi
if [ -s "$OUTPUT_FILE" ]; then
    echo "Znalezione duplikaty zapisano w $OUTPUT_FILE"
else
    echo "Brak duplikatów."
fi
# end
