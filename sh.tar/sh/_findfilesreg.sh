#!/bin/bash
# Dodałem obsługę wyrażeń regularnych, takich jak *.pdf czy *scan*.jpg.
# Teraz skrypt umożliwia wyszukiwanie plików według wzorców.

# Pytanie o nazwę pliku (obsługa wyrażeń regularnych)
echo -n "Podaj wzorzec nazwy pliku (np. *.pdf lub *scan*.jpg): "
read filename

# Sprawdzenie, czy nazwa pliku jest pusta lub zawiera tylko spacje
if [[ -z "${filename// /}" ]]; then
    echo "Błąd: Należy wprowadzić poprawny wzorzec nazwy pliku zawierający znaki."
    exit 1
fi

# Plik wynikowy
output_file="wynik.txt"

# Wyszukiwanie plików zgodnych z wyrażeniem i zapisywanie wyników
find / -type f -name "$filename" 2>/dev/null > "$output_file"

echo "Wyniki zapisano w pliku: $output_file"

