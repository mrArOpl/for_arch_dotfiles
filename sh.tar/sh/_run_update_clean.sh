#!/bin/bash
# _run_update_clean.sh - Update system + clean crap + log it
# OG-style system maintenance dla Manjaro/Arch

set -euo pipefail

# 📍 Ustawienia
LOGFILE="$HOME/og-tools/logs/update_$(date '+%Y-%m-%d_%H-%M').log"
mkdir -p "$(dirname "$LOGFILE")"

echo "[*] Starting update & cleanup at $(date)" | tee -a "$LOGFILE"

# 🔄 Aktualizacja systemu
echo "[+] Updating system packages..." | tee -a "$LOGFILE"
sudo pacman -Syu --noconfirm | tee -a "$LOGFILE"

# 🧹 Czyszczenie pacman cache (zostaw ostatnie 2 wersje)
echo "[+] Cleaning package cache..." | tee -a "$LOGFILE"
sudo paccache -r -k2 | tee -a "$LOGFILE"

# 🗑️ Usuwanie osieroconych pakietów
echo "[+] Removing orphans..." | tee -a "$LOGFILE"
sudo pacman -Rns $(pacman -Qtdq 2>/dev/null || echo '') --noconfirm | tee -a "$LOGFILE"

# 🧼 Czyszczenie journal logs (>50MB)
echo "[+] Cleaning journal logs..." | tee -a "$LOGFILE"
sudo journalctl --vacuum-size=50M | tee -a "$LOGFILE"

echo "[✓] Done. Logs saved to $LOGFILE"

