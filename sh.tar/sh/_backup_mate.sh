#!/bin/bash

# Nazwa pliku kopii
BACKUP_FILE="mate_backup_$(date +%Y%m%d_%H%M).zip"

echo "📦 Tworzę kopię ustawień środowiska MATE..."

# Co kopiujemy
zip -r $BACKUP_FILE \
    ~/.config/mate* \
    ~/.config/marco* \
    ~/.config/dconf \
    ~/.mate \
    ~/.gconf \
    ~/.local/share/mate* \
    ~/.themes \
    ~/.icons \
    ~/.fonts \
    -x "*/Cache/*"

echo "✅ Kopia zapisana jako $BACKUP_FILE"

