#!/bin/bash
# _vm_switcher_tui.sh – TUI Virtualization Switcher by ArO + AI
# Przełącza środowisko: VirtualBox <-> KVM/Virt-Manager
# Wymaga: dialog lub whiptail + sudo do modprobe.

TITLE="VM Switcher by ArO + AI"
BACKTITLE="VirtualBox <-> KVM / Virt-Manager"
HEIGHT=15
WIDTH=60
CHOICE_HEIGHT=5

# Detekcja narzędzia TUI
if command -v dialog >/dev/null 2>&1; then
    UI_TOOL="dialog"
elif command -v whiptail >/dev/null 2>&1; then
    UI_TOOL="whiptail"
else
    echo "Brak 'dialog' ani 'whiptail'. Zainstaluj jedno z nich:"
    echo "  sudo pacman -S dialog"
    echo "albo:"
    echo "  sudo pacman -S libnewt"  # whiptail
    exit 1
fi

# Funkcja wywołania TUI
tui_menu() {
    if [ "$UI_TOOL" = "dialog" ]; then
        dialog --clear \
            --backtitle "$BACKTITLE" \
            --title "$TITLE" \
            --menu "Wybierz środowisko wirtualizacji:" \
            $HEIGHT $WIDTH $CHOICE_HEIGHT \
            1 "VirtualBox (wyłącz KVM, włącz vboxdrv)" \
            2 "KVM / Virt-Manager (wyłącz VirtualBox)" \
            3 "Pokaż aktualny stan modułów" \
            2> /tmp/vm_switcher_choice.$$
        RET=$?
        CHOICE=$(cat /tmp/vm_switcher_choice.$$ 2>/dev/null)
        rm -f /tmp/vm_switcher_choice.$$
        [ $RET -ne 0 ] && exit 0
    else
        CHOICE=$(whiptail --clear \
            --backtitle "$BACKTITLE" \
            --title "$TITLE" \
            --menu "Wybierz środowisko wirtualizacji:" \
            $HEIGHT $WIDTH $CHOICE_HEIGHT \
            "1" "VirtualBox (wyłącz KVM, włącz vboxdrv)" \
            "2" "KVM / Virt-Manager (wyłącz VirtualBox)" \
            "3" "Pokaż aktualny stan modułów" \
            3>&1 1>&2 2>&3)
        [ $? -ne 0 ] && exit 0
    fi
}

show_info() {
    local msg="$1"
    if [ "$UI_TOOL" = "dialog" ]; then
        dialog --backtitle "$BACKTITLE" --title "$TITLE" --msgbox "$msg" 12 70
    else
        whiptail --backtitle "$BACKTITLE" --title "$TITLE" --msgbox "$msg" 12 70
    fi
}

while true; do
    tui_menu

    case "$CHOICE" in
        1)
            # VirtualBox ON
            sudo modprobe -r kvm_intel kvm_amd kvm 2>/dev/null
            sudo modprobe -r vboxdrv vboxnetflt vboxnetadp 2>/dev/null
            sudo modprobe vboxdrv 2>/dev/null

            if lsmod | grep -q vboxdrv; then
                MSG="Aktywne: VirtualBox\n\nZaładowane moduły:\n$(lsmod | egrep 'vbox|kvm' || echo 'brak kvm')"
            else
                MSG="Błąd: nie udało się załadować modułu vboxdrv.\n\nSprawdź:\n- czy zainstalowany jest linuxXXX-virtualbox-host-modules\n- logi: dmesg | grep -i vbox"
            fi
            show_info "$MSG"
            ;;
        2)
            # KVM / Virt-Manager ON
            sudo modprobe -r vboxdrv vboxnetflt vboxnetadp 2>/dev/null

            if grep -qi intel /proc/cpuinfo; then
                sudo modprobe kvm_intel 2>/dev/null
            else
                sudo modprobe kvm_amd 2>/dev/null
            fi
            sudo modprobe kvm 2>/dev/null

            if lsmod | grep -q kvm; then
                MSG="Aktywne: KVM / Virt-Manager\n\nZaładowane moduły:\n$(lsmod | egrep 'vbox|kvm' || echo 'brak vbox')"
            else
                MSG="Błąd: nie udało się załadować modułów KVM.\n\nSprawdź:\n- czy CPU wspiera VT-x/AMD-V\n- czy nie ma blacklistów w /etc/modprobe.d\n- logi: dmesg | grep -i kvm"
            fi
            show_info "$MSG"
            ;;
        3)
            # Status
            STATUS="$(lsmod | egrep 'vbox|kvm' || echo 'Brak aktywnych modułów vbox/kvm.')"
            show_info "Aktualny stan modułów:\n\n$STATUS"
            ;;
        *)
            exit 0
            ;;
    esac
done

