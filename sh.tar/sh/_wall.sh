#!/bin/bash

### BEGIN INIT INFO
# Provides: _firewall
# Required-Start: $local_fs $remote_fs
# Required-Stop: $local_fs $remote_fs
# Default-Start: 2 3 4 5
# Default-Stop: 0 1 6
# Short-Description: Start daemon at boot time
# Description: Enable service provided by daemon.
### END INIT INFO

# CZYSZCZENIE STARYCH REGUŁ
iptables -F
iptables -Z
iptables -X
iptables -F -t nat
iptables -X -t nat
iptables -Z -t nat
iptables -F -t filter
iptables -X -t filter
iptables -Z -t filter
iptables -F -t mangle
iptables -X -t mangle
iptables -Z -t mangle

# USTAWIENIE POLITYKI DZIAŁANIA
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT
# iptables -A INPUT -i lo -j ACCEPT
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT
# iptables -A FORWARD -m state --state ESTABLISHED,RELATED -j ACCEPT
iptables -A INPUT -p icmp --icmp-type echo-request -j REJECT --reject-with icmp-host-unreachable

# OCHRONA PRZED ATAKIEM PING OF DEATH
iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s -j LOG --log-prefix "Ping: "
iptables -A INPUT -p icmp --icmp-type echo-request -m limit --limit 1/s -j ACCEPT # Ping of death

# BLOKOWANIE TELNETU ORAZ LISTOWANYCH PORTOW
iptables -A OUTPUT -p tcp --dport telnet -j REJECT
iptables -A INPUT -p tcp --dport telnet -j REJECT
# iptables -A INPUT -p udp --dport 1:65454 -j REJECT
# iptables -A INPUT -p tcp --dport 2015 -j REJECT
# iptables -A INPUT -p udp --dport 849 -j REJECT
# iptables -A INPUT -p tcp --dport 137 -j REJECT
# iptables -A INPUT -p tcp --dport 138 -j REJECT
# iptables -A INPUT -p tcp --dport 139 -j REJECT
# iptables -A INPUT -p tcp --dport 445 -j REJECT
# iptables -A INPUT -p tcp --dport 67 -j REJECT
# iptables -A INPUT -p tcp --dport 68 -j REJECT
# iptables -A INPUT -p tcp --dport 1900 -j REJECT
# iptables -A INPUT -p tcp --dport 5353 -j REJECT
# iptables -A INPUT -p tcp --dport 1524 -j REJECT
# iptables -A INPUT -p tcp --dport 6667 -j REJECT
# iptables -A INPUT -p tcp --dport 31337 -j REJECT

# ZAPIS DO LOGA ODRZUCONYCH PAKIETÓW PRZYCHODZĄCYCH W KATALOGU var/log/messages
iptables -N LOGGING
iptables -A INPUT -j LOGGING
iptables -A LOGGING -m limit --limit 2/min -j LOG --log-prefix "IPTables-Dropped: " --log-level 4
iptables -A LOGGING -j DROP

# KONIEC
