#!/usr/bin/env bash
# Batch HTML translate via LibreTranslate API
# EN -> PL
# preserves HTML structure

set -euo pipefail

SRC="./en/krusader"
DST="./pl/krusader"
API="http://127.0.0.1:5000"
SRC_LANG="en"
DST_LANG="pl"

mkdir -p "$DST"

python3 02_translate_html_libre.py \
  "$SRC" "$DST" \
  --api "$API" \
  --source "$SRC_LANG" \
  --target "$DST_LANG"

echo "[✓] Tłumaczenie zakończone"

