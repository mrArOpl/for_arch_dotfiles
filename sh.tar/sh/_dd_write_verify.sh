#!/usr/bin/env bash
set -euo pipefail

ISO="${1:-}"
DEV="${2:-}"

if [[ -z "$ISO" || -z "$DEV" ]]; then
  echo "Użycie: $0 obraz.iso /dev/sdX"
  exit 1
fi

if [[ ! -f "$ISO" ]]; then
  echo "Brak pliku: $ISO"
  exit 1
fi

if [[ ! -b "$DEV" ]]; then
  echo "To nie jest blok device: $DEV"
  exit 1
fi

echo "[*] Źródło: $ISO"
echo "[*] Cel:     $DEV"
echo "[*] Rozmiar ISO: $(stat -c%s "$ISO") bajtów"

read -r -p "UWAGA: To skasuje $DEV. Kontynuować? (TAK): " ans
[[ "$ans" == "TAK" ]] || exit 1

echo "[*] Zapis dd..."
sudo dd if="$ISO" of="$DEV" bs=4M status=progress oflag=sync conv=fsync
sync

SZ=$(stat -c%s "$ISO")
CNT=$(( (SZ + 1048575) / 1048576 ))

echo "[*] Verify (sha256 z pierwszych $SZ bajtów urządzenia)..."
H1=$(sha256sum "$ISO" | awk '{print $1}')
H2=$(sudo dd if="$DEV" bs=1M count="$CNT" status=none | head -c "$SZ" | sha256sum | awk '{print $1}')

echo "[*] ISO: $H1"
echo "[*] DEV: $H2"

if [[ "$H1" == "$H2" ]]; then
  echo "[OK] Zapis zweryfikowany 1:1 ✅"
else
  echo "[FAIL] Różnice po zapisie ❌"
  exit 2
fi

