#!/bin/bash
#
# ArO (c)2021 persistence creator 
#             usb disk , parrot, kali, kodachi etc.. live
#
clear
echo ' ArO (c)2021 persistence creator , add partition etc.. '
echo ' --------------------------------------------------------------------- '
lsblk
echo ' Please choise usb disk, sdX (x=no. disk 1,2,..)'
read USB_D
echo $USB_D  ' - this usb disk is correct ? (Y/n)'
read YN
if [ "$YN" = "n" ] 
then
exit
fi
# options: n (create partition) nr 3 ,size, w (write) , q (quiet)
(echo n; echo p; echo 3; echo ; echo ; echo w) | fdisk /dev/$USB_D
USB_D=$USB_D"3"
mkfs.ext4 -L persistence /dev/$USB_D
e2label /dev/$USB_D persistence
mkdir -p /mnt/p
mount /dev/$USB_D /mnt/p
echo "/ union" > /mnt/p/persistence.conf
umount /dev/$USB_D
echo 'persistence created   ArO(c)2021 https://aro.5v.pl'
fdisk -l

# The End
