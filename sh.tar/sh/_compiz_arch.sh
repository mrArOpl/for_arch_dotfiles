#!/bin/bash

# Folder tymczasowy
mkdir -p ~/compiz-chaotic
cd ~/compiz-chaotic

# Lista paczek do pobrania
BASE_URL="https://builds.garudalinux.org/repos/chaotic-aur/x86_64"
# https://builds.garudalinux.org/repos/chaotic-aur/x86_64/
# Lista paczek
PACKAGES=(
    "compiz-0.9.14.2-9-x86_64.pkg.tar.zst"
    "compiz-plugins-main-0.9.14.2-5-x86_64.pkg.tar.zst"
    "compiz-plugins-extra-0.9.14.2-5-x86_64.pkg.tar.zst"
    "compizconfig-settings-manager-0.8.18-4-x86_64.pkg.tar.zst"
    "fusion-icon-0.1-5-x86_64.pkg.tar.zst"
)

echo "Pobieranie paczek z Chaotic-AUR..."

# Pobieranie
for pkg in "${PACKAGES[@]}"; do
    wget "$BASE_URL/$pkg"
done

echo "Instalacja paczek..."
sudo pacman -U *.pkg.tar.zst --noconfirm

echo "Czyszczenie..."
cd ~
rm -rf ~/compiz-chaotic

echo "Zakończone! Compiz zainstalowany. Uruchom:"
echo "fusion-icon &"
echo "lub"
echo "compiz --replace &"

