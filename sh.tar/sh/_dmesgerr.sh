#!/usr/bin/bash
################
#
# clear
# cat _dmesgerr.sh
# echo 'Searching dmesg , please any key'
# read
sudo dmesg | grep -i error
sudo dmesg | grep -i failed
sudo dmesg | grep -i corrupt
sudo dmesg | grep -i invalid
sudo dmesg | grep -i unnamed
sudo dmesg | grep -i uninitialized
sudo dmesg | grep -i wrong
sudo dmesg | grep -i bug
sudo dmesg | grep -i conflict
sudo dmesg | grep -i fault
sudo dmesg | grep -i panic
sudo dmesg | grep -i critical
sudo dmesg | grep -i warning
sudo dmesg | grep -i unexpected
sudo dmesg | grep -i dropped
sudo dmesg | grep -i "segfault"
sudo dmesg | grep -i "denied"
sudo dmesg | grep -i "unable"
sudo dmesg | grep -i "refused"
sudo dmesg | grep -i "no response"
sudo dmesg | grep -i "timeout"
sudo dmesg | grep -i "assert"
sudo dmesg | grep -i "overrun"
sudo dmesg | grep -i "out of range"
sudo dmesg | grep -i "underflow"
sudo dmesg | grep -i "overload"
sudo dmesg | grep -i "missing"
sudo dmesg | grep -i "failed to load"
sudo dmesg | grep -i "not found"
sudo dmesg | grep -i "unknown"
sudo dmesg | grep -i "device not ready"
sudo dmesg | grep -i "buffer overflow"
sudo dmesg | grep -i "stack smashing"

## ArO (c)2019
