#!/usr/bin/env bash
# _clone_user_xfce_paranoik.sh
#
# "Paranoik" user clone for Manjaro/Arch + XFCE
# - NO --delete (won't remove anything in destination)
# - LOG to file + stdout
# - XFCE-focused include list (copies only "look & feel" + a few safe essentials)
# - Optional "test-full" mode (copies almost everything, still avoids session tokens unless requested)
#
# Examples:
#   sudo ./_clone_user_xfce_paranoik.sh --src aro --dst aro2 --create-user --xfce-only --dry-run
#   sudo ./_clone_user_xfce_paranoik.sh --src aro --dst aro2 --create-user --xfce-only
#
#   # Test clone including Brave profile/cache (dangerous/private):
#   sudo ./_clone_user_xfce_paranoik.sh --src aro --dst aro_test --create-user --test-full --include-brave --include-secrets
#
# Notes:
# - This script is intentionally conservative. It avoids copying browsers & secrets by default.
# - To see what gets copied: use --dry-run first (always).
# - Run as root.

set -euo pipefail

# ---------------- defaults ----------------
SRC=""
DST=""
CREATE_USER=0
DRY_RUN=0

MODE="xfce-only"   # xfce-only | test-full
INCLUDE_BRAVE=0
INCLUDE_SECRETS=0  # ssh/gpg/keyrings
INCLUDE_HISTORY=0  # bash history etc.

SHELL_PATH="/bin/bash"
HOME_BASE="/home"
LOG_DIR="/var/log/userclone"
TIMESTAMP="$(date +%F_%H%M%S)"
LOG_FILE=""

RSYNC_BIN="$(command -v rsync || true)"

# ---------------- helpers ----------------
die() { echo "[-] $*" >&2; exit 1; }
ok()  { echo "[+] $*"; }
warn(){ echo "[!] $*" >&2; }

need_root() {
  [[ ${EUID:-$(id -u)} -eq 0 ]] || die "Run as root: sudo $0 ..."
}

usage() {
  cat <<EOF
Usage:
  $0 --src <user> --dst <user> [--create-user] [--xfce-only|--test-full] [options]

Core:
  --src USER           source username
  --dst USER           target username
  --create-user        create target user if it does not exist
  --dry-run            rsync dry run (no writes)

Modes:
  --xfce-only          copy only XFCE look&feel + safe essentials (default)
  --test-full          copy almost everything (still conservative unless you add include flags)

Risky includes (only if you REALLY want):
  --include-brave      also copy Brave profile/cache (private: cookies, sessions, extensions)
  --include-secrets    also copy secrets: ~/.ssh ~/.gnupg keyrings (high risk)
  --include-history    also copy shell histories (privacy)

Other:
  --shell PATH         shell for created user (default: /bin/bash)
  --home-base DIR      home base (default: /home)
  --log-dir DIR        log directory (default: /var/log/userclone)

Examples:
  sudo $0 --src aro --dst aro2 --create-user --xfce-only --dry-run
  sudo $0 --src aro --dst aro2 --create-user --xfce-only

  # test clone (dangerous):
  sudo $0 --src aro --dst aro_test --create-user --test-full --include-brave --include-secrets
EOF
}

user_exists() { id "$1" &>/dev/null; }

# ---------------- parse args ----------------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --src) SRC="${2:-}"; shift 2;;
    --dst) DST="${2:-}"; shift 2;;
    --create-user) CREATE_USER=1; shift;;
    --dry-run) DRY_RUN=1; shift;;

    --xfce-only) MODE="xfce-only"; shift;;
    --test-full) MODE="test-full"; shift;;

    --include-brave) INCLUDE_BRAVE=1; shift;;
    --include-secrets) INCLUDE_SECRETS=1; shift;;
    --include-history) INCLUDE_HISTORY=1; shift;;

    --shell) SHELL_PATH="${2:-}"; shift 2;;
    --home-base) HOME_BASE="${2:-}"; shift 2;;
    --log-dir) LOG_DIR="${2:-}"; shift 2;;

    -h|--help) usage; exit 0;;
    *) die "Unknown option: $1 (use --help)";;
  esac
done

# ---------------- checks ----------------
need_root
[[ -n "$RSYNC_BIN" ]] || die "rsync not found. Install: sudo pacman -S rsync"
[[ -n "$SRC" && -n "$DST" ]] || { usage; exit 1; }
[[ "$SRC" != "$DST" ]] || die "SRC and DST must be different."

user_exists "$SRC" || die "Source user does not exist: $SRC"

SRC_HOME="$HOME_BASE/$SRC"
DST_HOME="$HOME_BASE/$DST"

[[ -d "$SRC_HOME" ]] || die "Source home not found: $SRC_HOME"

# create log file early
mkdir -p "$LOG_DIR"
LOG_FILE="$LOG_DIR/${0##*/}_${SRC}_to_${DST}_${TIMESTAMP}.log"

# tee stdout+stderr to log
exec > >(tee -a "$LOG_FILE") 2>&1

ok "Log file: $LOG_FILE"
ok "Mode: $MODE"
ok "Flags: dry_run=$DRY_RUN include_brave=$INCLUDE_BRAVE include_secrets=$INCLUDE_SECRETS include_history=$INCLUDE_HISTORY"

# Ensure dst user exists
if user_exists "$DST"; then
  ok "Target user exists: $DST"
else
  if [[ $CREATE_USER -eq 1 ]]; then
    ok "Creating user: $DST"
    useradd -m -d "$DST_HOME" -s "$SHELL_PATH" "$DST"
    passwd "$DST" || true
  else
    die "Target user does not exist: $DST (use --create-user)"
  fi
fi

[[ -d "$DST_HOME" ]] || die "Target home not found: $DST_HOME"

# ---------------- rsync base flags ----------------
# Paranoik: no --delete
RSYNC_FLAGS=(
  "-aAX"
  "--numeric-ids"
  "--info=progress2"
  "--human-readable"
  "--partial"
)

[[ $DRY_RUN -eq 1 ]] && RSYNC_FLAGS+=("--dry-run")

# ---------------- include/exclude logic ----------------
# We build two strategies:
# 1) XFCE-ONLY: start from "exclude everything", then include selected paths.
# 2) TEST-FULL: start from "copy everything" with a safe exclude list; optionally re-include risky bits.

# Common session/token junk to always avoid unless user explicitly asks (we still won't copy these; they regenerate)
ALWAYS_EXCLUDE=(
  "--exclude=.Xauthority"
  "--exclude=.ICEauthority"
  "--exclude=.dbus/"
  "--exclude=.xauth*"
)

# Safe essentials for "look & feel" in XFCE:
# - XFCE config
# - themes/icons/fonts
# - wallpaper pictures (optional but handy)
# - gtk settings
# - thunar & xfce terminal configs
XFCE_INCLUDE=(
  "--include=/.config/"
  "--include=/.config/xfce4/***"
  "--include=/.config/xfce4-panel/***"
  "--include=/.config/xfconf/***"
  "--include=/.config/Thunar/***"
  "--include=/.config/xfce4-terminal/***"
  "--include=/.config/gtk-3.0/***"
  "--include=/.config/gtk-4.0/***"
  "--include=/.gtkrc-2.0"
  "--include=/.themes/***"
  "--include=/.icons/***"
  "--include=/.fonts/***"
  "--include=/.local/share/icons/***"
  "--include=/.local/share/themes/***"
  "--include=/.local/share/fonts/***"
  "--include=/.local/share/xfce4/***"
  "--include=/.local/share/backgrounds/***"
  "--include=/Pictures/***"
  "--include=/Obrazy/***"
)

# In XFCE-ONLY we exclude everything else.
XFCE_ONLY_FILTER=(
  "--exclude=*"
)

# Safe excludes for test-full (copy almost everything but avoid secrets by default)
TESTFULL_EXCLUDES=(
  "--exclude=.cache/"
  "--exclude=.local/share/Trash/"
  "--exclude=.recently-used.xbel"
  "--exclude=.bash_history"
  "--exclude=.zsh_history"
  "--exclude=.python_history"
  "--exclude=.viminfo"
  "--exclude=.lesshst"
  "--exclude=.wget-hsts"
  "--exclude=.ssh/"
  "--exclude=.gnupg/"
  "--exclude=.pki/"
  "--exclude=.local/share/keyrings/"
  "--exclude=.local/share/kwalletd/"
  "--exclude=.kde/share/apps/kwallet/"
  "--exclude=.password-store/"
  "--exclude=.config/keepassxc/"
  "--exclude=.mozilla/"
  "--exclude=.config/google-chrome/"
  "--exclude=.config/chromium/"
  "--exclude=.config/BraveSoftware/"  # can be added back with --include-brave
  "--exclude=.config/vivaldi/"
  "--exclude=.config/opera/"
)

# Optionally include Brave profile in test-full
BRAVE_INCLUDE=(
  "--include=/.config/BraveSoftware/***"
)

# Optionally include secrets in test-full
SECRETS_INCLUDE=(
  "--include=/.ssh/***"
  "--include=/.gnupg/***"
  "--include=/.pki/***"
  "--include=/.local/share/keyrings/***"
  "--include=/.password-store/***"
)

# Optionally include histories
HISTORY_INCLUDE=(
  "--include=/.bash_history"
  "--include=/.zsh_history"
  "--include=/.python_history"
  "--include=/.viminfo"
  "--include=/.lesshst"
  "--include=/.wget-hsts"
)

# ---------------- perform copy ----------------
ok "Cloning: $SRC_HOME/ -> $DST_HOME/"
if [[ "$MODE" == "xfce-only" ]]; then
  ok "XFCE-ONLY: include XFCE look&feel + themes/icons/fonts + wallpapers; exclude everything else."

  # For include/exclude filters to work predictably, we exclude everything, then include desired paths.
  # We must also include directories leading to included files; rsync uses /*** trick above.
  rsync "${RSYNC_FLAGS[@]}" \
    "${ALWAYS_EXCLUDE[@]}" \
    "${XFCE_INCLUDE[@]}" \
    "${XFCE_ONLY_FILTER[@]}" \
    "$SRC_HOME/" "$DST_HOME/"

elif [[ "$MODE" == "test-full" ]]; then
  ok "TEST-FULL: copy most things; excludes secrets/browsers by default unless you add include flags."

  # Copy almost everything with excludes
  rsync "${RSYNC_FLAGS[@]}" \
    "${ALWAYS_EXCLUDE[@]}" \
    "${TESTFULL_EXCLUDES[@]}" \
    "$SRC_HOME/" "$DST_HOME/"

  # If user wants Brave, explicitly rsync that directory as a second pass (more readable/controlled)
  if [[ $INCLUDE_BRAVE -eq 1 ]]; then
    ok "Including Brave profile: ~/.config/BraveSoftware (PRIVATE!)"
    rsync "${RSYNC_FLAGS[@]}" "${ALWAYS_EXCLUDE[@]}" \
      "$SRC_HOME/.config/BraveSoftware/" "$DST_HOME/.config/BraveSoftware/" || true
  fi

  # Include secrets as a second pass
  if [[ $INCLUDE_SECRETS -eq 1 ]]; then
    warn "Including SECRETS (ssh/gpg/keyrings) — this is high risk. You asked for it."
    for d in ".ssh" ".gnupg" ".pki" ".local/share/keyrings" ".password-store"; do
      if [[ -e "$SRC_HOME/$d" ]]; then
        rsync "${RSYNC_FLAGS[@]}" "${ALWAYS_EXCLUDE[@]}" \
          "$SRC_HOME/$d/" "$DST_HOME/$d/" || true
      fi
    done
  fi

  if [[ $INCLUDE_HISTORY -eq 1 ]]; then
    warn "Including histories (privacy)."
    for f in ".bash_history" ".zsh_history" ".python_history" ".viminfo" ".lesshst" ".wget-hsts"; do
      if [[ -e "$SRC_HOME/$f" ]]; then
        rsync "${RSYNC_FLAGS[@]}" "${ALWAYS_EXCLUDE[@]}" \
          "$SRC_HOME/$f" "$DST_HOME/$f" || true
      fi
    done
  fi
else
  die "Unknown MODE: $MODE"
fi

# ---------------- ownership + cleanup ----------------
if [[ $DRY_RUN -eq 0 ]]; then
  ok "Fixing ownership: chown -R $DST:$DST $DST_HOME"
  chown -R "$DST:$DST" "$DST_HOME"

  ok "Cleaning session/token leftovers in destination (safe regen):"
  rm -rf "$DST_HOME/.dbus" 2>/dev/null || true
  rm -f  "$DST_HOME/.ICEauthority" "$DST_HOME/.Xauthority" 2>/dev/null || true

  # If xfce-only, we do NOT touch destination cache except those tokens above.
  # If test-full, we already excluded cache by default, but user may want it; we won't nuke it.
  ok "Done."
  ok "Log saved: $LOG_FILE"
  ok "Tip: first login as $DST will regenerate per-user session bits."
else
  ok "Dry-run complete."
  ok "Review log: $LOG_FILE"
fi

exit 0

