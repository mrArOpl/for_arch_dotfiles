#!/usr/bin/env bash
# _robots_analyzer.sh
# Analyze robots.txt and sitemaps without touching Disallow paths.
# Usage: ./_robots_analyzer.sh https://example.com

set -euo pipefail

URL="${1:-}"
if [[ -z "${URL}" ]]; then
  echo "Usage: $0 https://example.com"
  exit 1
fi

# Normalize base URL (strip trailing slash)
BASE="${URL%/}"

ua="Mozilla/5.0 (X11; Linux x86_64) robots-analyzer/1.0"

tmpdir="$(mktemp -d)"
cleanup() { rm -rf "$tmpdir"; }
trap cleanup EXIT

robots_url="${BASE}/robots.txt"
robots_file="${tmpdir}/robots.txt"
headers_file="${tmpdir}/headers.txt"

fetch() {
  local u="$1" out="$2"
  curl -fsSL -A "$ua" --max-time 20 "$u" -o "$out"
}

fetch_headers() {
  local u="$1" out="$2"
  curl -fsSI -A "$ua" --max-time 20 "$u" > "$out"
}

echo "==> Fetching: ${robots_url}"
if ! curl -fsSI -A "$ua" --max-time 15 "$robots_url" >/dev/null 2>&1; then
  echo "[-] robots.txt not accessible (no file or blocked)."
  echo "[i] That's not unusual. Exiting."
  exit 0
fi

fetch "$robots_url" "$robots_file"
fetch_headers "$BASE/" "$headers_file" || true

echo
echo "=============================="
echo "ROBOTS.TXT (raw, first 120 lines)"
echo "=============================="
nl -ba "$robots_file" | sed -n '1,120p'
echo

# Extract sitemaps
mapfile -t SITEMAPS < <(grep -iE '^\s*Sitemap:\s*' "$robots_file" \
  | sed -E 's/^\s*Sitemap:\s*//I' \
  | sed 's/\r$//' \
  | awk 'NF')

# If none declared, try default /sitemap.xml
if [[ "${#SITEMAPS[@]}" -eq 0 ]]; then
  SITEMAPS=("${BASE}/sitemap.xml")
fi

echo "=============================="
echo "Detected sitemap candidates"
echo "=============================="
printf '%s\n' "${SITEMAPS[@]}" | nl -ba
echo

echo "=============================="
echo "Server hints (from / headers)"
echo "=============================="
# Show some header clues (not always present)
grep -iE '^(server:|via:|x-powered-by:|cf-ray:|x-cache:|x-served-by:|x-amz-|x-sucuri|x-waf|set-cookie:)' "$headers_file" 2>/dev/null || echo "[i] No revealing headers (or request failed)."
echo

# Heuristic: tech fingerprint from homepage (light)
home_html="${tmpdir}/home.html"
if fetch "$BASE/" "$home_html" 2>/dev/null; then
  tech_flags=()
  grep -qi 'wp-content|wp-includes' "$home_html" && tech_flags+=("wordpress")
  grep -qi 'drupal|sites/default' "$home_html" && tech_flags+=("drupal")
  grep -qi 'joomla' "$home_html" && tech_flags+=("joomla")
  grep -qi 'shopify' "$home_html" && tech_flags+=("shopify")
  grep -qi 'ghost' "$home_html" && tech_flags+=("ghost")
  grep -qi 'grav' "$home_html" && tech_flags+=("grav")
  [[ "${#tech_flags[@]}" -eq 0 ]] && tech_flags+=("unknown/static-ish")

  echo "=============================="
  echo "Light tech fingerprint (from homepage HTML)"
  echo "=============================="
  printf '%s\n' "${tech_flags[@]}" | sed 's/^/- /'
  echo
else
  tech_flags=("unknown")
fi

# Parse robots rules per UA
# Output table: UA | TYPE | PATH
rules_file="${tmpdir}/rules.tsv"
awk '
BEGIN{ua="(none)"}
{
  line=$0
  sub(/\r$/, "", line)
  # strip comments
  sub(/[[:space:]]*#.*/, "", line)
  if (line ~ /^[[:space:]]*$/) next

  if (tolower(line) ~ /^[[:space:]]*user-agent[[:space:]]*:/) {
    ua=line
    sub(/^[[:space:]]*User-agent[[:space:]]*:/i, "", ua)
    gsub(/^[[:space:]]+|[[:space:]]+$/, "", ua)
    if (ua=="") ua="(empty)"
    next
  }

  if (tolower(line) ~ /^[[:space:]]*(allow|disallow)[[:space:]]*:/) {
    type=line
    if (tolower(type) ~ /^[[:space:]]*allow/) t="Allow"; else t="Disallow"
    path=line
    sub(/^[[:space:]]*(Allow|Disallow)[[:space:]]*:/i, "", path)
    gsub(/^[[:space:]]+|[[:space:]]+$/, "", path)
    if (path=="") path="(empty)"
    print ua "\t" t "\t" path
  }
}
' "$robots_file" > "$rules_file"

echo "=============================="
echo "Parsed rules (User-agent / Allow / Disallow)"
echo "=============================="
if [[ -s "$rules_file" ]]; then
  awk -F'\t' '{printf "- UA: %-20s | %-8s | %s\n",$1,$2,$3}' "$rules_file" | sed -n '1,200p'
  [[ "$(wc -l < "$rules_file")" -gt 200 ]] && echo "[i] (truncated at 200 lines)"
else
  echo "[i] No Allow/Disallow rules found."
fi
echo

# Honeypot suspicion heuristics
# Flags "juicy" targets and mismatches
echo "=============================="
echo "Honeypot suspicion report (heuristics)"
echo "=============================="

juicy_re='(^|/)(\.env|\.git|\.svn|backup|backups|db|dump|sql|phpmyadmin|admin(istrator)?|secret|private|config|passwd|shadow|token|key|keys|credential|creds|old|test|staging|dev)(/|$)'
wp_re='(^|/)(wp-admin|wp-login\.php|xmlrpc\.php|wp-content|wp-includes)(/|$)'

suspicious=0

while IFS=$'\t' read -r UA TYPE PATH; do
  # Only consider disallows as "bait"
  [[ "$TYPE" != "Disallow" ]] && continue
  [[ "$PATH" == "(empty)" ]] && continue

  # Juicy bait
  if echo "$PATH" | grep -Eqi "$juicy_re"; then
    echo "[!] Juicy Disallow bait: UA='$UA' PATH='$PATH'"
    suspicious=$((suspicious+1))
  fi

  # WP mismatch: if looks static-ish but robots lists WP stuff
  if echo "$PATH" | grep -Eqi "$wp_re"; then
    if printf '%s\n' "${tech_flags[@]}" | grep -qi 'unknown/static-ish|grav|unknown'; then
      echo "[!] Possible tech mismatch (WP paths in robots but homepage not WP-ish): PATH='$PATH' (UA='$UA')"
      suspicious=$((suspicious+1))
    fi
  fi

  # Too many admin variants
  if echo "$PATH" | grep -Eqi '(^|/)admin' ; then
    :
  fi
done < "$rules_file"

# Count admin-like disallows
admin_count="$(awk -F'\t' '$2=="Disallow" && tolower($3) ~ /(^|\/)admin/ {c++} END{print c+0}' "$rules_file")"
if [[ "$admin_count" -ge 4 ]]; then
  echo "[!] Many admin-like Disallow entries (${admin_count}). Could be a net for scanners."
  suspicious=$((suspicious+1))
fi

if [[ "$suspicious" -eq 0 ]]; then
  echo "[i] No strong honeypot signals found (heuristics only)."
fi
echo

# Sitemap fetch + URL extraction
echo "=============================="
echo "Sitemap analysis"
echo "=============================="

extract_urls_from_xml_fallback() {
  # naive extraction for <loc>...</loc>
  grep -oE '<loc>[^<]+'</loc>' "$1" | sed -E 's#</?loc>##g'
}

process_sitemap() {
  local sm_url="$1"
  local sm_file="${tmpdir}/$(echo "$sm_url" | sed 's#[^a-zA-Z0-9]#_#g').xml"

  echo "==> Fetching sitemap: $sm_url"
  if ! curl -fsSL -A "$ua" --max-time 20 "$sm_url" -o "$sm_file" 2>/dev/null; then
    echo "[-] Could not fetch sitemap: $sm_url"
    return 0
  fi

  # Detect sitemapindex vs urlset (simple)
  if grep -qi '<sitemapindex' "$sm_file"; then
    echo "[i] sitemapindex detected (index of sitemaps)."
    # Extract child sitemap locs
    local children
    if command -v python3 >/dev/null 2>&1; then
      children="$(python3 - <<'PY'
import sys, xml.etree.ElementTree as ET
p=sys.argv[1]
try:
  t=ET.parse(p); r=t.getroot()
except Exception:
  print(""); sys.exit(0)
# handle namespaces
ns=""
if r.tag.startswith("{"):
  ns=r.tag.split("}")[0].strip("{")
def q(tag): return f"{{{ns}}}{tag}" if ns else tag
locs=[]
for sm in r.findall(q("sitemap")):
  loc=sm.find(q("loc"))
  if loc is not None and loc.text:
    locs.append(loc.text.strip())
print("\n".join(locs))
PY
"$sm_file")"
    else
      children="$(extract_urls_from_xml_fallback "$sm_file")"
    fi

    if [[ -n "${children}" ]]; then
      echo "$children" | sed 's/^/- child: /'
      echo
      while IFS= read -r child; do
        [[ -z "$child" ]] && continue
        process_sitemap "$child"
      done <<< "$children"
    else
      echo "[-] Could not extract child sitemaps from index."
    fi
  else
    echo "[i] urlset sitemap detected (list of URLs)."
    urls=""
    if command -v python3 >/dev/null 2>&1; then
      urls="$(python3 - <<'PY'
import sys, xml.etree.ElementTree as ET
p=sys.argv[1]
try:
  t=ET.parse(p); r=t.getroot()
except Exception:
  print(""); sys.exit(0)
ns=""
if r.tag.startswith("{"):
  ns=r.tag.split("}")[0].strip("{")
def q(tag): return f"{{{ns}}}{tag}" if ns else tag
locs=[]
for u in r.findall(q("url")):
  loc=u.find(q("loc"))
  if loc is not None and loc.text:
    locs.append(loc.text.strip())
print("\n".join(locs))
PY
"$sm_file")"
    else
      urls="$(extract_urls_from_xml_fallback "$sm_file")"
    fi

    if [[ -n "${urls}" ]]; then
      count="$(echo "$urls" | awk 'NF{c++} END{print c+0}')"
      echo "[+] Extracted URLs: $count"
      # Show first 40 URLs as sample
      echo "$urls" | awk 'NF{print}' | sed -n '1,40p' | sed 's/^/- /'
      [[ "$count" -gt 40 ]] && echo "[i] (showing first 40)"
      echo
    else
      echo "[-] Could not extract URLs from sitemap."
    fi
  fi
}

for sm in "${SITEMAPS[@]}"; do
  process_sitemap "$sm"
done

echo "=============================="
echo "Done."
echo "Notes:"
echo "- Script does NOT request any Disallow paths."
echo "- Suspicion signals are heuristics, not proof."
echo "=============================="
#
#  Use:
#   chmod +x _robots_analyzer.sh
#   ./_robots_analyzer.sh https://twoja-strona.pl  ,  bash _robots_analyzer.sh https://twoja-strona.pl
#
# End


