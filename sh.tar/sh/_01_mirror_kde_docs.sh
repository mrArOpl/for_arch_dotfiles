#!/usr/bin/env bash
# KDE Docs mirror (offline)
# ArO OG edition

set -euo pipefail

URL="https://docs.kde.org/stable5/en/krusader/krusader/"
DEST="./en/krusader"

mkdir -p "$DEST"

wget --mirror \
     --convert-links \
     --adjust-extension \
     --page-requisites \
     --no-parent \
     -e robots=off \
     -P "$DEST" \
     "$URL"

echo "[✓] Mirror gotowy w: $DEST"
echo "    Otwórz lokalnie: index.html"

