#!/bin/bash

### BEGIN INIT INFO
#
#  Skrypt: _drop4ip
#
### END INIT INFO

# CZYSZCZENIE STARYCH REGUŁ IP4
iptables -F
iptables -Z
iptables -X
iptables -F -t nat
iptables -X -t nat
iptables -Z -t nat
iptables -F -t filter
iptables -X -t filter
iptables -Z -t filter
iptables -F -t mangle
iptables -X -t mangle
iptables -Z -t mangle

# USTAWIENIE DROP 4
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT DROP

#
echo "ip6tables ip4:"
iptables -S
