#!/bin/bash
#
# Sprawdź najpierw źródła audio:
# bash
# pactl list short sources
#
# Przyklad:
# 0   alsa_input.pci-0000_00_1b.0.analog-stereo     ... # mikrofon
# 1   alsa_output.pci-0000_00_1b.0.analog-stereo.monitor  ... # dźwięk systemowy
#
# Ścieżki źródeł audio – zamień na własne
MIC="alsa_input.pci-0000_00_1b.0.analog-stereo"
SYS="alsa_output.pci-0000_00_1b.0.analog-stereo.monitor"

# Rozdzielczość ekranu – sprawdź `xdpyinfo | grep dimensions`
RES="1366x768"

# Nagrywaj przez 60 sekund (zmień -t)
ffmpeg \
-f x11grab -video_size $RES -i :0.0 -c:v libx264 -preset ultrafast ekran.mp4 \
-f pulse -i $MIC mic.wav \
-f pulse -i $SYS system.wav \
-t 60
##
#
# Co ten skrypt robi?
#   ekran.mp4 – wideo z ekranu
#   mic.wav – mikrofon
#   system.wav – dźwięk systemowy (np. VLC, YouTube)
# Jeśli chcesz nagrywać bez limitu, po prostu usuń -t 60