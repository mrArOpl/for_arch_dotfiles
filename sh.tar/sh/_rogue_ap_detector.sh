#!/bin/bash
# _rogue_ap_detector.sh – wykrywa złośliwe AP, DNS spoof i MITM
# autor: ArO + ChatGPT OG

DOMAINS=("google.com" "facebook.com" "github.com")
GOOD_DNS="8.8.8.8"
LOGFILE="/tmp/rogue_ap_log.txt"
GATEWAY=$(ip route | grep default | awk '{print $3}')

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "\n🔍 ${YELLOW}Rozpoczynam detekcję rogue AP i MITM...${NC}"
echo "----- $(date) -----" >> "$LOGFILE"

for DOMAIN in "${DOMAINS[@]}"; do
  echo -e "\n🌐 Sprawdzam domenę: ${DOMAIN}"

  # Publiczny DNS
  PUB_IP=$(dig +short @"$GOOD_DNS" "$DOMAIN" | head -n1)

  # DNS lokalny (może złośliwy)
  LOC_IP=$(dig +short @"$GATEWAY" "$DOMAIN" | head -n1)

  echo -e "  🛰️  Z 8.8.8.8: ${GREEN}$PUB_IP${NC}"
  echo -e "  🎭  Z routera : ${YELLOW}$LOC_IP${NC}"

  if [[ "$PUB_IP" != "$LOC_IP" ]]; then
    echo -e "${RED}[!] WYKRYTO DNS SPOOFING!${NC} $DOMAIN → $LOC_IP"
    echo "[!] DNS spoofing $DOMAIN: $LOC_IP (zamiast $PUB_IP)" >> "$LOGFILE"
  else
    echo -e "${GREEN}[✓] DNS OK${NC}"
  fi

  # Cert SSL – fingerprint
  echo -e "  🔐 Sprawdzam certyfikat SSL..."
  CN=$(echo | openssl s_client -servername $DOMAIN -connect $DOMAIN:443 2>/dev/null | openssl x509 -noout -subject | grep CN= | cut -d= -f2-)
  ISSUER=$(echo | openssl s_client -servername $DOMAIN -connect $DOMAIN:443 2>/dev/null | openssl x509 -noout -issuer | cut -d= -f2-)

  echo -e "     CN: ${CN}"
  echo -e "     Issuer: ${ISSUER}"

  if echo "$ISSUER" | grep -qiE "mitmproxy|burp|self-signed|attack"; then
    echo -e "${RED}[!] WYKRYTO FAŁSZYWY CERT SSL!${NC}"
    echo "[!] Rogue cert for $DOMAIN: $ISSUER" >> "$LOGFILE"
  else
    echo -e "${GREEN}[✓] Cert OK${NC}"
  fi

done

echo -e "\n📁 Log zapisany w: ${LOGFILE}"
#
# OPIS:
#  Co wykrywa realnie:
#  złośliwy router (IPFire, honeypot, PineAP),

#  MITM typu ZAP/Burp z self-signed certem,

#  DNS spoof,

#  podmianę certy SSL (złym CA).
