#!/bin/bash

### BEGIN INIT INFO
#
#  Skrypt: _allowip.sh
#
### END INIT INFO

# CZYSZCZENIE STARYCH REGUŁ IP4

iptables -F
iptables -Z
iptables -X
iptables -F -t nat
iptables -X -t nat
iptables -Z -t nat
iptables -F -t filter
iptables -X -t filter
iptables -Z -t filter
iptables -F -t mangle
iptables -X -t mangle
iptables -Z -t mangle

# USTAWIENIE allow ip4
iptables -P INPUT ACCEPT
iptables -P FORWARD ACCEPT
iptables -P OUTPUT ACCEPT

#
echo "iptables ip4:"
iptables -S

## end
