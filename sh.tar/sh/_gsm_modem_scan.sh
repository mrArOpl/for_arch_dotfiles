#!/bin/bash

echo "[INFO] Skrypt do identyfikacji modemów GSM USB"
echo "---------------------------------------------"

# Szukamy urządzeń USB potencjalnie będących modemami GSM
lsusb | grep -iE 'huawei|zte|alcatel|qualcomm|novatel|sierra|option|longcheer|ublox'

echo ""
echo "[INFO] Wyszukiwanie urządzeń ttyUSB i ttyACM..."
echo "---------------------------------------------"

for dev in /dev/ttyUSB* /dev/ttyACM*; do
    [ -e "$dev" ] || continue
    echo "[INFO] Sprawdzam $dev"
    echo "AT" > "$dev" & sleep 1
    cat "$dev" & sleep 1
    echo "---"
done

echo ""
echo "[INFO] Wykrywanie z ls -l /dev/serial/by-id/"
ls -l /dev/serial/by-id/ 2>/dev/null || echo "Brak linków symbolicznych dla urządzeń szeregowych."

echo ""
echo "[INFO] Dodatkowe informacje z dmesg:"
dmesg | grep -i "usb" | tail -n 30

echo ""
echo "[INFO] Gotowe. Jeśli chcesz sprawdzić konkretny port, użyj minicom:"
echo "sudo minicom -D /dev/ttyUSB0"

