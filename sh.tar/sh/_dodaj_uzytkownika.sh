#!/bin/bash

# Sprawdzenie, czy skrypt jest uruchomiony jako root
if [ "$EUID" -ne 0 ]; then
  echo "Uruchom ten skrypt jako root (sudo)."
  exit 1
fi

read -p "Podaj nazwę nowego użytkownika: " NAZWA
read -s -p "Podaj hasło dla użytkownika: " HASLO
echo
read -p "Czy chcesz skopiować ustawienia XFCE z innego użytkownika? (t/n): " KOPIUJ

if [[ "$KOPIUJ" == "t" || "$KOPIUJ" == "T" ]]; then
  read -p "Podaj nazwę istniejącego użytkownika (źródło konfiguracji): " STARY
fi

# Tworzenie użytkownika
useradd -m -s /bin/bash "$NAZWA"
echo "$NAZWA:$HASLO" | chpasswd
# Dodanie do grupy wheel , uprawnienia sudo
# usermod -aG wheel "$NAZWA"

# Tworzenie domyślnych katalogów (Dokumenty itd.)
sudo -u "$NAZWA" xdg-user-dirs-update

# Opcjonalne kopiowanie konfiguracji XFCE
if [[ "$KOPIUJ" == "t" || "$KOPIUJ" == "T" ]]; then
  if [ -d "/home/$STARY/.config/xfce4" ]; then
    mkdir -p "/home/$NAZWA/.config"
    cp -r "/home/$STARY/.config/xfce4" "/home/$NAZWA/.config/"
    chown -R "$NAZWA:$NAZWA" "/home/$NAZWA/.config/xfce4"
    echo "Skopiowano konfigurację XFCE z użytkownika '$STARY'."
  else
    echo "Nie znaleziono konfiguracji XFCE u użytkownika '$STARY'."
  fi
fi

echo "Użytkownik '$NAZWA' został utworzony."

