#!/usr/bin/env bash
# _parrot_docker_toolbox.sh
# ParrotSec Docker toolbox launcher for Manjaro/Arch
# by ArO & AI — OG edition

set -euo pipefail

IMG_DEFAULT="parrotsec/security"
NAME_DEFAULT="parrot"
WORKDIR_DEFAULT="${HOME}/parrot-work"
SHELL_DEFAULT="bash"

# -------- helpers --------
die() { echo "[!] $*" >&2; exit 1; }
ok()  { echo "[+] $*"; }
info(){ echo "[*] $*"; }

need_cmd() { command -v "$1" >/dev/null 2>&1 || die "Brak komendy: $1"; }

usage() {
  cat <<'EOF'
Użycie:
  ./_parrot_docker_toolbox.sh <komenda> [opcje]

Komendy:
  setup                 - sprawdza dockera + sugeruje podstawową konfigurację
  pull                  - pobiera obraz (domyślnie parrotsec/security)
  start                 - uruchamia kontener w tle (host network + caps + bind /work)
  shell                 - wchodzi do kontenera (bash)
  run <cmd...>          - odpala jedną komendę w kontenerze i kończy
  update                - apt update/upgrade w kontenerze (w środku)
  logs                  - pokazuje logi kontenera
  stop                  - zatrzymuje kontener
  purge                 - usuwa kontener (bez ruszania obrazów) + czyści nieużywane
  info                  - status: obraz/kontener/volume/workdir

Opcje środowiskowe:
  IMG=parrotsec/security        - zmień obraz
  NAME=parrot                   - zmień nazwę kontenera
  WORKDIR=~/parrot-work         - katalog roboczy mapowany do /work
  SHELL=bash                    - domyślna powłoka

Przykłady:
  IMG=parrotsec/security NAME=parrot ./_parrot_docker_toolbox.sh pull
  ./_parrot_docker_toolbox.sh start
  ./_parrot_docker_toolbox.sh shell
  ./_parrot_docker_toolbox.sh run nmap -sV 127.0.0.1
EOF
}

IMG="${IMG:-$IMG_DEFAULT}"
NAME="${NAME:-$NAME_DEFAULT}"
WORKDIR="${WORKDIR:-$WORKDIR_DEFAULT}"
SHELL="${SHELL:-$SHELL_DEFAULT}"

docker_ok() {
  need_cmd docker
  docker info >/dev/null 2>&1 || die "Docker nie działa. Odpal: sudo systemctl enable --now docker (i dodaj usera do grupy docker)."
}

container_exists() {
  docker ps -a --format '{{.Names}}' | grep -qx "$NAME"
}

container_running() {
  docker ps --format '{{.Names}}' | grep -qx "$NAME"
}

ensure_workdir() {
  mkdir -p "$WORKDIR"
}

cmd_setup() {
  need_cmd docker
  if ! systemctl is-active --quiet docker; then
    info "Docker service nieaktywny. Odpal to (jako root):"
    echo "  sudo systemctl enable --now docker"
  else
    ok "Docker service działa."
  fi

  if ! groups | tr ' ' '\n' | grep -qx docker; then
    info "Nie jesteś w grupie docker. Zrób:"
    echo "  sudo usermod -aG docker $USER"
    echo "  newgrp docker"
  else
    ok "Jesteś w grupie docker."
  fi

  info "Test: docker run hello-world"
}

cmd_pull() {
  docker_ok
  info "Pobieram obraz: $IMG"
  docker pull "$IMG"
  ok "Gotowe."
}

cmd_start() {
  docker_ok
  ensure_workdir

  if container_running; then
    ok "Kontener '$NAME' już działa."
    exit 0
  fi

  if container_exists; then
    info "Kontener '$NAME' istnieje, startuję go..."
    docker start "$NAME" >/dev/null
    ok "Wystartował."
    exit 0
  fi

  info "Tworzę i uruchamiam kontener '$NAME' z:"
  info "- host networking"
  info "- cap: NET_ADMIN + NET_RAW (dla raw sockets, nmap/arp itp.)"
  info "- bind: $WORKDIR -> /work"
  echo

  docker run -d \
    --name "$NAME" \
    --network host \
    --cap-add NET_ADMIN \
    --cap-add NET_RAW \
    -v "$WORKDIR:/work" \
    -w /work \
    "$IMG" \
    sleep infinity >/dev/null

  ok "Kontener działa w tle. Wejdź: ./_parrot_docker_toolbox.sh shell"
}

cmd_shell() {
  docker_ok
  if ! container_running; then
    info "Kontener nie działa — odpalam start."
    cmd_start
  fi
  info "Wchodzę do '$NAME' (/work). Wyjście: exit"
  docker exec -it "$NAME" "$SHELL"
}

cmd_run() {
  docker_ok
  ensure_workdir
  shift || true
  [[ $# -ge 1 ]] || die "Brak komendy. Np: run nmap -sV 127.0.0.1"

  info "Odpalam jednorazowo w kontenerze (bez tworzenia stałego): $*"
  docker run -it --rm \
    --network host \
    --cap-add NET_ADMIN \
    --cap-add NET_RAW \
    -v "$WORKDIR:/work" \
    -w /work \
    "$IMG" \
    "$@"
}

cmd_update() {
  docker_ok
  if ! container_running; then
    info "Kontener nie działa — odpalam start."
    cmd_start
  fi

  info "Update systemu w kontenerze (apt update && apt -y upgrade)"
  docker exec -it "$NAME" bash -lc "apt update && DEBIAN_FRONTEND=noninteractive apt -y upgrade"
  ok "Zrobione."
}

cmd_logs() {
  docker_ok
  container_exists || die "Kontener '$NAME' nie istnieje."
  docker logs --tail 200 -f "$NAME"
}

cmd_stop() {
  docker_ok
  container_running || die "Kontener '$NAME' nie działa."
  docker stop "$NAME" >/dev/null
  ok "Zatrzymany."
}

cmd_purge() {
  docker_ok
  if container_exists; then
    info "Usuwam kontener '$NAME'..."
    docker rm -f "$NAME" >/dev/null || true
    ok "Usunięty."
  else
    info "Kontener '$NAME' nie istnieje."
  fi

  info "Czyszczę nieużywane graty Dockera (bezpiecznie):"
  docker system prune -f >/dev/null
  ok "Oczyszczone."
}

cmd_info() {
  docker_ok
  echo "IMG     : $IMG"
  echo "NAME    : $NAME"
  echo "WORKDIR : $WORKDIR"
  echo "SHELL   : $SHELL"
  echo
  if container_exists; then
    info "Kontener istnieje:"
    docker ps -a --filter "name=^/${NAME}$" --format "  - {{.Names}} | {{.Status}} | {{.Image}}"
  else
    info "Kontener nie istnieje."
  fi
  echo
  info "Czy obraz jest lokalnie?"
  docker images --format '{{.Repository}}:{{.Tag}}' | grep -Fqx "$IMG" && echo "  - TAK" || echo "  - NIE"
}

# -------- main --------
main() {
  [[ $# -ge 1 ]] || { usage; exit 1; }

  case "${1:-}" in
    -h|--help|help) usage ;;
    setup) cmd_setup ;;
    pull)  cmd_pull ;;
    start) cmd_start ;;
    shell) cmd_shell ;;
    run)   cmd_run "$@" ;;
    update) cmd_update ;;
    logs)  cmd_logs ;;
    stop)  cmd_stop ;;
    purge) cmd_purge ;;
    info)  cmd_info ;;
    *)
      die "Nieznana komenda: $1 (daj --help)"
      ;;
  esac
}

main "$@"
#
# INSTALL AND USE:
# nano _parrot_docker_toolbox.sh
# chmod +x _parrot_docker_toolbox.sh
#
# ./_parrot_docker_toolbox.sh setup
# ./_parrot_docker_toolbox.sh pull
# ./_parrot_docker_toolbox.sh start
# ./_parrot_docker_toolbox.sh shell
#
# Typowe uzycie “jednorazowe” (bez stałego kontenera)
#
# ./_parrot_docker_toolbox.sh run whoami
# ./_parrot_docker_toolbox.sh run nmap -sV 127.0.0.1
#
# Bonus OG: parę tipów, żeby to było wygodne
# Wszystkie wyniki wrzucasz do ~/parrot-work i masz je na hoście.
# start tworzy kontener “na stałe” i trzyma go na sleep infinity, więc wchodzisz shell kiedy chcesz.
# run to “single shot” i po komendzie kontener znika (czysto).
#
# END


