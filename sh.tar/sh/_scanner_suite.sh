#!/bin/bash
# _scanner_suite.sh by ArO & AI
# 🔍 Skrypt zawierający 3 funkcje skanowania IP:
# 1. Pełny skaner IP (ping + porty)
# 2. Hunter kamer IP
# 3. Angry-lite: szybki skan sieci
# Wszystko z eksportem do pliku TXT!

OUTPUT_DIR="./scanner_results"
mkdir -p "$OUTPUT_DIR"

function scanner_ip_og() {
    echo "[*] Pełny skan IP + portów (20 najpopularniejszych)"
    read -p "Zakres IP (np. 192.168.1.0/24): " RANGE
    OUT="$OUTPUT_DIR/ip_scan_$(date +%F_%H-%M).txt"
    nmap -Pn -sS -T4 --top-ports 20 "$RANGE" -oN "$OUT"
    echo "[✓] Wyniki zapisane do: $OUT"
}

function ip_cam_hunter() {
    echo "[*] Hunter kamer IP – porty 80, 8080, 554, 81"
    read -p "Zakres IP (np. 192.168.0.0/24): " RANGE
    OUT="$OUTPUT_DIR/ip_cam_$(date +%F_%H-%M).txt"
    nmap -Pn -p 80,8080,554,81 "$RANGE" --open -oN "$OUT"
    echo "[✓] Wyniki zapisane do: $OUT"
}

function angry_lite() {
    echo "[*] Angry-lite – szybki skan hostów live"
    read -p "Zakres IP (np. 192.168.1.0/24): " RANGE
    OUT="$OUTPUT_DIR/angry_lite_$(date +%F_%H-%M).txt"
    nmap -sn "$RANGE" | grep "Nmap scan report for" | awk '{print $5}' > "$OUT"
    echo "[✓] Hosty aktywne zapisane do: $OUT"
}

# === MENU ===
while true; do
    echo -e "\n🔥 SCANNER MENU 🔥"
    echo "1. scanner_ip_og → Ping + Top 20 ports"
    echo "2. ip_cam_hunter → Kamerki IP na klasycznych portach"
    echo "3. angry_lite → Hosty aktywne"
    echo "4. Wyjście"
    read -p "Wybierz opcję [1-4]: " CHOICE

    case "$CHOICE" in
        1) scanner_ip_og ;;
        2) ip_cam_hunter ;;
        3) angry_lite ;;
        4) echo "OG out. 🔚"; exit 0 ;;
        *) echo "[!] Nieprawidłowy wybór." ;;
    esac
done
