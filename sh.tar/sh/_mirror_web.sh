#!/bin/sh

# === KONFIGURACJA ===
URL="https://example.com"                     # <- Adres strony do pobrania
TARGET_DIR="/mnt/dysk_www/web/mysite"        # <- Katalog docelowy (serwer WWW)

# === TWORZENIE KATALOGU ===
mkdir -p "$TARGET_DIR"

# === POBIERANIE STRONY ===
wget --mirror \
     --convert-links \
     --adjust-extension \
     --page-requisites \
     --no-parent \
     --no-check-certificate \
     -P "$TARGET_DIR/tmp" "$URL"

# === AKTUALIZACJA STRONY ===
rm -rf "$TARGET_DIR/current"
mv "$TARGET_DIR/tmp/${URL#*//}" "$TARGET_DIR/current"
rm -rf "$TARGET_DIR/tmp"

# === USTAWIENIE WŁAŚCIWYCH UPRAWNIEŃ ===
chown -R www:www "$TARGET_DIR"
chmod -R 755 "$TARGET_DIR"

echo "✅ Strona $URL zaktualizowana w $TARGET_DIR/current"

