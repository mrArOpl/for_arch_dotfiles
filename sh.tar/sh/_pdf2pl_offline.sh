#!/usr/bin/env bash
# _pdf2pl_offline.sh
# PDF (EN) -> PL offline: pdftotext OR OCR(tesseract) -> Argos (argospm) -> output .txt/.pdf
set -euo pipefail

usage() {
  cat <<'EOF'
Użycie:
  _pdf2pl_offline.sh input.pdf [output_prefix] [--mode auto|text|ocr] [--from en] [--to pl]

Przykłady:
  _pdf2pl_offline.sh instrukcja.pdf
  _pdf2pl_offline.sh instrukcja.pdf instrukcja_PL --mode text
  _pdf2pl_offline.sh skan.pdf skan_PL --mode ocr

Wyniki:
  output_prefix.pl.txt
  output_prefix.pl.pdf (jeśli jest pandoc ALBO wkhtmltopdf)
EOF
}

MODE="auto"
FROM="en"
TO="pl"

if [[ ${1:-} == "-h" || ${1:-} == "--help" || $# -lt 1 ]]; then usage; exit 0; fi

IN="$1"
OUT_PREFIX="${2:-$(basename "${IN%.*}")_PL}"

shift || true
shift || true

while [[ $# -gt 0 ]]; do
  case "$1" in
    --mode) MODE="${2:-auto}"; shift 2 ;;
    --from) FROM="${2:-en}"; shift 2 ;;
    --to)   TO="${2:-pl}"; shift 2 ;;
    *) echo "Nieznana opcja: $1"; usage; exit 2 ;;
  esac
done

need() { command -v "$1" >/dev/null 2>&1 || { echo "Brak komendy: $1"; exit 3; }; }

need file
need mktemp
need sed
need awk

# Preferowane narzędzia:
# - tekst: pdftotext (poppler)
# - OCR: tesseract
# - tłumaczenie: argospm + argos-translate (Argos Translate CLI)
# - PDF wyjściowy: pandoc albo wkhtmltopdf

TMPDIR="$(mktemp -d)"
trap 'rm -rf "$TMPDIR"' EXIT

TXT_EN="$TMPDIR/in.en.txt"
TXT_PL="$TMPDIR/out.pl.txt"
PDF_PL="${OUT_PREFIX}.pl.pdf"
TXT_OUT="${OUT_PREFIX}.pl.txt"

echo "[*] Input:  $IN"
echo "[*] Output: $TXT_OUT (+ opcjonalnie PDF)"

# --- Detekcja czy PDF ma tekst ---
is_text_pdf() {
  if command -v pdftotext >/dev/null 2>&1; then
    pdftotext "$IN" - 2>/dev/null | head -c 4000 | tr -d '\000' | grep -q '[[:alnum:]]'
  else
    return 1
  fi
}

# --- Ekstrakcja tekstu ---
extract_text() {
  need pdftotext
  echo "[*] Ekstrakcja tekstu (pdftotext)..."
  pdftotext "$IN" "$TXT_EN"
  # lekkie czyszczenie: null, CRLF
  tr -d '\000' < "$TXT_EN" | sed 's/\r$//' > "${TXT_EN}.clean"
  mv "${TXT_EN}.clean" "$TXT_EN"
}

# --- OCR ---
ocr_pdf() {
  need tesseract
  echo "[*] OCR (tesseract) – to może chwilę pomęczyć CPU..."
  # Wypluwa txt: out.txt
  tesseract "$IN" "$TMPDIR/ocr" -l "${FROM}" >/dev/null 2>&1 || {
    echo "[!] OCR się wysypał. Spróbuj: sudo pacman -S tesseract-data-eng (albo odpowiedni lang)."
    exit 4
  }
  cp "$TMPDIR/ocr.txt" "$TXT_EN"
}

# --- Modele Argos (argospm) ---
ensure_argos_model() {
  need argospm
  # Wg dokumentacji: argospm update / search / install translate-xx_yy :contentReference[oaicite:0]{index=0}
  echo "[*] Sprawdzam model Argos: ${FROM}->${TO}"
  argospm update >/dev/null 2>&1 || true

  # Najczęstszy format paczek: translate-en_pl
  PKG="translate-${FROM}_${TO}"

  if argospm search | awk '{print $1}' | grep -qx "$PKG"; then
    # sprawdź czy zainstalowany
    if ! argospm list 2>/dev/null | awk '{print $1}' | grep -qx "$PKG"; then
      echo "[*] Instaluję model: $PKG"
      argospm install "$PKG"
    else
      echo "[*] Model już zainstalowany."
    fi
  else
    echo "[!] Nie widzę paczki $PKG w indexie Argos."
    echo "    Zrób ręcznie: argospm search | grep '${FROM}_${TO}'"
    echo "    i podaj mi nazwę paczki – dopasujemy skrypt."
    exit 5
  fi
}

# --- Tłumaczenie ---
translate_text() {
  # W zależności od instalacji CLI bywa: argos-translate / argos-translate-cli / argostranslate
  if command -v argos-translate >/dev/null 2>&1; then
    echo "[*] Tłumaczenie (argos-translate)..."
    argos-translate --from "$FROM" --to "$TO" < "$TXT_EN" > "$TXT_PL"
  elif command -v argos-translate-cli >/dev/null 2>&1; then
    echo "[*] Tłumaczenie (argos-translate-cli)..."
    argos-translate-cli --from-lang "$FROM" --to-lang "$TO" < "$TXT_EN" > "$TXT_PL"
  else
    echo "[!] Nie mam CLI do tłumaczenia (argos-translate / argos-translate-cli)."
    echo "    Masz argospm, ale brak wrappera do translate. Użyj portable-setup z dołu."
    exit 6
  fi
}

# --- Zapis TXT + PDF ---
make_pdf() {
  cp "$TXT_PL" "$TXT_OUT"
  echo "[*] Zapisano: $TXT_OUT"

  if command -v pandoc >/dev/null 2>&1; then
    echo "[*] Robię PDF przez pandoc..."
    pandoc "$TXT_OUT" -o "$PDF_PL" >/dev/null 2>&1 || {
      echo "[!] pandoc nie zrobił PDF (często brakuje LaTeX). Zostawiam tylko TXT."
      return 0
    }
    echo "[*] Zapisano: $PDF_PL"
  elif command -v wkhtmltopdf >/dev/null 2>&1; then
    echo "[*] Robię PDF przez wkhtmltopdf (TXT->HTML->PDF)..."
    HTML="$TMPDIR/out.html"
    awk 'BEGIN{print "<html><meta charset=\"utf-8\"><body><pre>"} {print} END{print "</pre></body></html>"}' \
      "$TXT_OUT" > "$HTML"
    wkhtmltopdf "$HTML" "$PDF_PL" >/dev/null 2>&1 && echo "[*] Zapisano: $PDF_PL" || true
  else
    echo "[*] Brak pandoc i wkhtmltopdf — zostaje TXT (to i tak najczyściej)."
  fi
}

# --- MAIN ---
case "$MODE" in
  auto)
    if is_text_pdf; then MODE="text"; else MODE="ocr"; fi
    ;;
  text|ocr) ;;
  *) echo "Zły --mode: $MODE"; exit 2 ;;
esac

echo "[*] Tryb: $MODE"

if [[ "$MODE" == "text" ]]; then
  extract_text
else
  ocr_pdf
fi

ensure_argos_model
translate_text
make_pdf

echo "[✓] Gotowe."

