#!/usr/bin/env bash
#
#  _github_proxy_helper.sh
#
#  OG-helper ArO + AI do pobierania z GitHuba przez proxy:
#  - omija mulący transfer / rate-limity / focha GitHuba
#  - generuje URL z proxy albo od razu pobiera plik
#
#  Obsługiwane proxy:
#   1) ghproxy.com
#   2) ghp.ci
#   3) gh.api.99988866.xyz (mirror-style)
#
#  Użycie:
#    1) Bez parametrów -> wchodzi w menu interaktywne
#    2) Z parametrami:
#         ./_github_proxy_helper.sh URL [OUTPUT] [PROXY]
#       gdzie PROXY ∈ {ghproxy, ghp, mirror}
#
#  Przykłady:
#    ./_github_proxy_helper.sh https://github.com/user/repo/archive/refs/heads/main.zip
#    ./_github_proxy_helper.sh https://github.com/user/repo/archive/main.zip repo.zip ghproxy
#
#  Made for: ArO (OG Linux ninja) 🔥

set -euo pipefail

# --- KONFIG: domyślne proxy ----------------------------------------------

DEFAULT_PROXY="ghproxy"   # ghproxy | ghp | mirror

# Mapowanie nazw na URL-e
get_proxy_prefix() {
    local proxy="$1"
    case "$proxy" in
        ghproxy)
            echo "https://ghproxy.com/"
            ;;
        ghp)
            echo "https://ghp.ci/"
            ;;
        mirror)
            echo "https://gh.api.99988866.xyz/"
            ;;
        *)
            echo "https://ghproxy.com/"
            ;;
    esac
}

# --- FUNKCJE OG -----------------------------------------------------------

log_info() {
    echo "[*] $*"
}

log_err() {
    echo "[!] $*" >&2
}

usage() {
    cat <<EOF
Użycie:
  $0                 # tryb interaktywny (menu)
  $0 URL [OUTPUT] [PROXY]

Parametry:
  URL        - pełny link do GitHuba (repo, release, raw, zip, cokolwiek)
  OUTPUT     - nazwa pliku wyjściowego (opcjonalnie, domyślnie: nazwa z URL)
  PROXY      - ghproxy | ghp | mirror  (opcjonalnie, domyślnie: $DEFAULT_PROXY)

Przykłady:
  $0 https://github.com/user/repo/archive/main.zip
  $0 https://raw.githubusercontent.com/user/repo/main/script.sh script.sh ghp
EOF
}

# Tworzy URL z proxy
build_proxied_url() {
    local proxy_name="$1"
    local url="$2"

    local prefix
    prefix=$(get_proxy_prefix "$proxy_name")

    # Prosty concat
    echo "${prefix}${url}"
}

# Pobranie pliku (wget/curl – bierzemy co jest)
download_via_proxy() {
    local url="$1"
    local output="${2:-}"
    local proxy_name="${3:-$DEFAULT_PROXY}"

    local proxied_url
    proxied_url=$(build_proxied_url "$proxy_name" "$url")

    log_info "Proxy: $proxy_name"
    log_info "URL źródłowy: $url"
    log_info "URL z proxy:  $proxied_url"

    if command -v wget >/dev/null 2>&1; then
        if [[ -n "$output" ]]; then
            log_info "Pobieram wget → $output"
            wget -O "$output" "$proxied_url"
        else
            log_info "Pobieram wget (auto-nazwa pliku)"
            wget "$proxied_url"
        fi
    elif command -v curl >/dev/null 2>&1; then
        if [[ -n "$output" ]]; then
            log_info "Pobieram curl → $output"
            curl -L "$proxied_url" -o "$output"
        else
            # curl bez -o = pluje na stdout, więc lepimy nazwę z URL
            local fname
            fname=$(basename "$url")
            [[ -z "$fname" || "$fname" == "/" ]] && fname="download.bin"
            log_info "Pobieram curl → $fname"
            curl -L "$proxied_url" -o "$fname"
        fi
    else
        log_err "Brak wget i curl – zainstaluj chociaż jedno, OG!"
        exit 1
    fi

    log_info "Gotowe. Jak coś, sprawdź sumy/virus-scan – nie ufamy nikomu 😈"
}

# --- TRYB INTERAKTYWNY (MENU) --------------------------------------------

choose_proxy_menu() {
    echo
    echo "== Wybór proxy GitHub =="
    echo "1) ghproxy.com          (stabilne, klasyk)"
    echo "2) ghp.ci               (często bardzo szybkie)"
    echo "3) gh.api.99988866.xyz  (mirror-style)"
    echo
    read -r -p "Wybierz [1-3] (Enter = domyślne: $DEFAULT_PROXY): " choice

    case "$choice" in
        1|"")
            echo "ghproxy"
            ;;
        2)
            echo "ghp"
            ;;
        3)
            echo "mirror"
            ;;
        *)
            log_err "Zły wybór, jadę na domyślnym: $DEFAULT_PROXY"
            echo "$DEFAULT_PROXY"
            ;;
    esac
}

interactive_menu() {
    while true; do
        echo
        echo "==============================="
        echo "  GitHub Proxy Helper (ArO OG)"
        echo "==============================="
        echo "1) Wygeneruj URL z proxy"
        echo "2) Pobierz plik przez proxy"
        echo "3) Zmień domyślne proxy (tylko w tej sesji)"
        echo "4) Info / pomoc"
        echo "0) Wyjście"
        echo

        read -r -p "Wybierz opcję [0-4]: " opt
        case "$opt" in
            1)
                read -r -p "Podaj URL GitHub (publiczny): " url
                [[ -z "$url" ]] && { log_err "Pusty URL, wracam do menu."; continue; }

                local_proxy=$(choose_proxy_menu)
                proxied=$(build_proxied_url "$local_proxy" "$url")
                echo
                echo "Proxied URL:"
                echo "$proxied"
                echo
                ;;
            2)
                read -r -p "Podaj URL GitHub (zip/release/raw): " url
                [[ -z "$url" ]] && { log_err "Pusty URL, wracam do menu."; continue; }

                read -r -p "Podaj nazwę pliku wyjściowego (Enter = auto): " out
                local_proxy=$(choose_proxy_menu)
                download_via_proxy "$url" "$out" "$local_proxy"
                ;;
            3)
                echo
                echo "Aktualne domyślne proxy: $DEFAULT_PROXY"
                NEW_PROXY=$(choose_proxy_menu)
                DEFAULT_PROXY="$NEW_PROXY"
                echo "Nowe domyślne proxy (tylko w tej sesji): $DEFAULT_PROXY"
                ;;
            4)
                usage
                ;;
            0)
                echo "Spadam. Miłego łupania GitHuba, Ninja 😎"
                exit 0
                ;;
            *)
                log_err "Nie ten klawisz, spróbuj jeszcze raz."
                ;;
        esac
    done
}

# --- MAIN ---------------------------------------------------------------

if [[ "${1:-}" == "-h" || "${1:-}" == "--help" ]]; then
    usage
    exit 0
fi

if [[ $# -ge 1 ]]; then
    # Tryb nieinteraktywny
    URL="$1"
    OUTPUT="${2:-}"
    PROXY="${3:-$DEFAULT_PROXY}"
    download_via_proxy "$URL" "$OUTPUT" "$PROXY"
else
    # Tryb interaktywny
    interactive_menu
fi

