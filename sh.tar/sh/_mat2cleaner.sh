#!/bin/bash

# OG cleaner by ArO + AI
# Czyści metadane we WSZYSTKICH plikach obsługiwanych przez mat2
# Bez tworzenia kopii --inplace

TARGET="${1:-.}"   # domyślnie bieżący katalog
LOG="mat2_errors.log"

echo "[*] Start czyszczenia metadanych w: $TARGET"
echo "[*] Log błędów: $LOG"
echo "" > "$LOG"

# Szukanie wszystkich plików (rekurencyjnie) i przepuszczenie przez mat2 --inplace
find "$TARGET" -type f -print0 | \
  xargs -0 -I{} sh -c '
    echo ">> Obrabiam: {}"
    mat2 --inplace "{}" 2>>'"$LOG"'
  '

echo ""
echo "[✓] Zakończone! Sprawdź ewentualne błędy w $LOG (jeśli jest pusty, wszystko git)."

