#!/bin/bash

OUT="adb_scan_report_$(date +%F_%H-%M).txt"

echo "=== ARO + AI ANDROID SECURITY SCAN ===" > $OUT
echo "Raport: $OUT" >> $OUT
echo "" >> $OUT

echo "[1] Informacje o urządzeniu..." >> $OUT
adb shell getprop | grep "ro." >> $OUT

echo "" >> $OUT
echo "[2] Lista procesów (ps -A)..." >> $OUT
adb shell ps -A >> $OUT

echo "" >> $OUT
echo "[3] Podejrzane nazwy procesów (rat/spy/keylog)..." >> $OUT
adb shell ps -A | grep -Ei "rat|spy|agent|key|remote|steal|hack" >> $OUT

echo "" >> $OUT
echo "[4] Lista pakietów z lokalizacją APK..." >> $OUT
adb shell pm list packages -f >> $OUT

echo "" >> $OUT
echo "[5] Podejrzane pakiety (spy/rat/monitor/remote)" >> $OUT
adb shell pm list packages | grep -Ei "spy|rat|monitor|remote|stealth" >> $OUT

echo "" >> $OUT
echo "[6] Magisk modules..." >> $OUT
adb shell ls /data/adb/modules >> $OUT 2>/dev/null

echo "" >> $OUT
echo "[7] Otwarty ruch sieciowy (netstat)..." >> $OUT
adb shell netstat -tulpn >> $OUT

echo "" >> $OUT
echo "[8] Zmodyfikowane pliki /system (ostatnie 30 dni)..." >> $OUT
adb shell find /system -type f -mtime -30 >> $OUT 2>/dev/null

echo "" >> $OUT
echo "[9] Zmodyfikowane pliki /vendor (ostatnie 30 dni)..." >> $OUT
adb shell find /vendor -type f -mtime -30 >> $OUT 2>/dev/null

echo "" >> $OUT
echo "[10] Usługi systemowe (dumpsys)" >> $OUT
adb shell service list >> $OUT

echo "" >> $OUT
echo "=== KONIEC SKANU ===" >> $OUT

echo ""
echo "✔ Raport zapisany do pliku: $OUT"
echo "✔ Przejrzyj sekcje [3], [5], [7], [8], [9] – tam wychodzą syfy."

