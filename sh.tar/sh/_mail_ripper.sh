#!/bin/bash
# by ArO & AI - minimalistyczny email hunter z curl + grep

if [ -z "$1" ]; then
    echo "Użycie: $0 <URL>"
    exit 1
fi

URL="$1"
UA="Mozilla/5.0 OG-Bash"

echo "[*] Pobieram źródło: $URL"

curl -s -A "$UA" "$URL" | grep -Eio "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}" | sort -u

