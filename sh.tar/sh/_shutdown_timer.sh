#!/bin/bash

# Funkcja do wyłączenia systemu po określonej dacie i godzinie
shutdown_by_date() {
    # Wczytanie daty i godziny
    read -p "Podaj datę i godzinę wyłączenia (format dd.mm.rrrr gg): " date_time
    # Formatowanie daty na format Unix (timestamp)
    shutdown_time=$(date -d "$date_time" +%s)
    current_time=$(date +%s)

    # Obliczenie różnicy
    time_diff=$((shutdown_time - current_time))

    if [ $time_diff -gt 0 ]; then
        # Uruchomienie poweroff po upływie określonego czasu
        echo "System zostanie wyłączony o $date_time."
        sleep $time_diff
        poweroff
    else
        echo "Podana data i godzina już minęły. Wybierz inną."
    fi
}

# Funkcja do wyłączenia systemu po określonej liczbie godzin
shutdown_by_hours() {
    # Wczytanie liczby godzin
    read -p "Podaj liczbę godzin działania systemu (zakres 1-9999): " hours

    # Sprawdzenie poprawności danych
    if [ "$hours" -gt 0 ] && [ "$hours" -lt 10000 ]; then
        # Uruchomienie poweroff po upływie określonego czasu w godzinach
        echo "System zostanie wyłączony za $hours godzin."
        sleep $((hours * 3600))
        poweroff
    else
        echo "Niepoprawna liczba godzin. Podaj wartość z zakresu 1-9999."
    fi
}

# Główne pytanie do użytkownika
echo "Wybierz poweroff: Data (d) lub Czas pracy (c)"
read -p "Wybór (d/c): " choice

# Obsługa odpowiedzi użytkownika
if [[ "$choice" == [Dd] ]]; then
    shutdown_by_date
elif [[ "$choice" == [Cc] ]]; then
    shutdown_by_hours
else
    echo "Nieprawidłowy wybór, spróbuj ponownie."
fi

