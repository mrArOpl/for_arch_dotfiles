#!/bin/bash
# _halny_port_scan.sh – Skan i analiza dziwnych portów routera Halny
# ArO + ChatGPT OG-style

TARGET=${1:-192.168.1.1}
PORTS_FILE="./ports.txt"
LOGFILE="/tmp/halny_scan_$(date +%F_%H-%M).log"
BANNER_TMP="/tmp/banner_$RANDOM.txt"
CAPFILE="/tmp/halny_22666.pcap"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'

echo -e "${YELLOW}[+] Skanuję host: $TARGET${NC}"
echo "----- HALNY SCAN START $(date) for $TARGET -----" > "$LOGFILE"

# Loop przez podejrzane porty
while read -r PORT; do
  echo -e "\n${YELLOW}[~] Port: $PORT${NC}" | tee -a "$LOGFILE"
  # Scan pojedynczego portu
  nc -vz -w 2 "$TARGET" "$PORT" 2>&1 | tee -a "$LOGFILE"

  # Banner grab
  timeout 3 bash -c "echo | nc $TARGET $PORT > $BANNER_TMP"
  if [[ -s "$BANNER_TMP" ]]; then
    echo -e "${GREEN}[✓] Banner:$(cat $BANNER_TMP)${NC}" | tee -a "$LOGFILE"
  else
    echo "[x] Brak odpowiedzi / brak banneru" >> "$LOGFILE"
  fi
done < "$PORTS_FILE"

# 🔍 Sniff pakietów z 22666 – opcjonalnie (tylko lokalnie)
echo -e "${YELLOW}\n[+] Nasłuch TCP:22666 przez 15s (tcpdump)...${NC}"
sudo timeout 15 tcpdump -i any port 22666 -nn -s 0 -w "$CAPFILE"

echo -e "${GREEN}\n[✓] Zakończono. Log: $LOGFILE, PCAP: $CAPFILE${NC}"

