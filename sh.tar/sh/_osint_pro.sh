#!/bin/bash

# Skrypt instalacyjny dla narzędzi OSINT
# Używany na systemie opartym na Debianie/Ubuntu (zainstalowanie niezbędnych narzędzi do OSINT)

# Sprawdzamy, czy skrypt jest uruchamiany jako root (superużytkownik)
if [ "$(id -u)" -ne 0 ]; then
  echo "Skrypt musi być uruchomiony jako root (sudo)."
  exit 1
fi

# Aktualizacja systemu
echo "Aktualizowanie systemu..."
apt update && apt upgrade -y

# Instalacja podstawowych narzędzi
echo "Instalowanie podstawowych narzędzi OSINT..."

# Aktualizacja i instalacja narzędzi
apt install -y python3 python3-pip git curl wget jq nmap \
  whois dnsutils build-essential python3-dev libssl-dev \
  libffi-dev python3-setuptools

# Instalacja narzędzi Python
pip3 install requests beautifulsoup4 scrapy

# Instalacja Recon-ng (OSINT framework)
echo "Instalowanie Recon-ng..."
git clone https://github.com/lanmaster53/recon-ng.git
cd recon-ng
pip3 install -r requirements.txt
echo "Zakończono instalację Recon-ng."

# Instalacja TheHarvester (OSINT)
echo "Instalowanie TheHarvester..."
git clone https://github.com/laramies/theHarvester.git
cd theHarvester
pip3 install -r requirements.txt
echo "Zakończono instalację TheHarvester."

# Instalacja Sherlock (szukaj kont użytkowników w serwisach)
echo "Instalowanie Sherlock..."
git clone https://github.com/sherlock-project/sherlock.git
cd sherlock
pip3 install -r requirements.txt
echo "Zakończono instalację Sherlock."

# Instalacja linPEAS (Linux Privilege Escalation Script)
echo "Instalowanie linPEAS..."
git clone https://github.com/carlospolop/privilege-escalation-awesome-scripts-suite.git
cd privilege-escalation-awesome-scripts-suite
chmod +x linpeas.sh
echo "Zakończono instalację linPEAS."

# Instalacja Nmap (skanowanie sieci)
echo "Instalowanie Nmap..."
apt install -y nmap
echo "Zakończono instalację Nmap."

# Instalacja Wireshark (analiza pakietów)
echo "Instalowanie Wireshark..."
apt install -y wireshark
echo "Zakończono instalację Wireshark."

# Instalacja Nikto (skanowanie podatności aplikacji webowych)
echo "Instalowanie Nikto..."
apt install -y nikto
echo "Zakończono instalację Nikto."

# Instalacja Aircrack-ng (ataki na sieci Wi-Fi)
echo "Instalowanie Aircrack-ng..."
apt install -y aircrack-ng
echo "Zakończono instalację Aircrack-ng."

# Instalacja Metasploit Framework (penetracyjne testowanie)
echo "Instalowanie Metasploit Framework..."
apt install -y metasploit-framework
echo "Zakończono instalację Metasploit Framework."

# Instalacja Hydra (brute force dla protokołów)
echo "Instalowanie Hydra..."
apt install -y hydra
echo "Zakończono instalację Hydra."

# Instalacja Wget i Curl (narzędzia do pobierania danych)
echo "Instalowanie Wget i Curl..."
apt install -y wget curl
echo "Zakończono instalację Wget i Curl."

# Instalacja Git (jeśli nie ma)
echo "Instalowanie Git..."
apt install -y git
echo "Zakończono instalację Git."

# Instalacja Wireshark (do analizy sieci)
echo "Instalowanie Wireshark..."
apt install -y wireshark
echo "Zakończono instalację Wireshark."

# Instalacja OWASP ZAP (narzędzie do analizy aplikacji webowych)
echo "Instalowanie OWASP ZAP..."
apt install -y zaproxy
echo "Zakończono instalację OWASP ZAP."

# Instalacja Sublist3r (szuka subdomen)
echo "Instalowanie Sublist3r..."
git clone https://github.com/aboul3la/Sublist3r.git
cd Sublist3r
pip3 install -r requirements.txt
echo "Zakończono instalację Sublist3r."

# Instalacja Shodan (wyszukiwarka urządzeń w internecie)
echo "Instalowanie Shodan..."
pip3 install shodan
echo "Zakończono instalację Shodan."

# Instalacja dnsrecon (narzędzie do analizy DNS)
echo "Instalowanie dnsrecon..."
apt install -y dnsrecon
echo "Zakończono instalację dnsrecon."

# Instalacja Httprobe (narzędzie do sprawdzania aktywności subdomen)
echo "Instalowanie Httprobe..."
go get -u github.com/tomnomnom/httprobe
echo "Zakończono instalację Httprobe."

# Instalacja Traceroute (do śledzenia tras sieciowych)
echo "Instalowanie Traceroute..."
apt install -y traceroute
echo "Zakończono instalację Traceroute."

# Instalacja SubdomainFinder (do wyszukiwania subdomen)
echo "Instalowanie SubdomainFinder..."
git clone https://github.com/nsonaniya2010/SubDomainFinder.git
cd SubDomainFinder
pip3 install -r requirements.txt
echo "Zakończono instalację SubdomainFinder."

# Podsumowanie
echo "Instalacja narzędzi OSINT zakończona! Możesz teraz używać ich do analizy danych."

# Powrót do głównego katalogu
cd ~

# Wskazówki:
# 1. Możesz uruchomić każde narzędzie z katalogu, w którym zostało zainstalowane.
# 2. Możesz dostosować ten skrypt, dodając kolejne narzędzia w zależności od potrzeb.

exit 0

