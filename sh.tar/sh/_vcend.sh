#!/bin/bash
# dismound all in the VeraCrypt
# ArO(c)2021
clear
echo ' '
echo '_______________________________________'
echo ' ArO(c)2021 - VeraCrypt dismounted all '
veracrypt -d
echo ' '
echo ' ArO(c)2021 - ok...'
echo ' '
cd /media
ls
cd anty
ls
