#!/bin/bash
#
#  Pobiera całe strony i podstrony z zachowaniem struktury linków. (https://example.com)
#
wget --mirror --convert-links --adjust-extension --page-requisites --no-parent https://example.com
#
#  --mirror – pełne lustrzane kopiowanie
#  --convert-links – dostosowanie linków do lokalnych
#  --page-requisites – pobranie CSS, JS, obrazków itd.
#   Następnie kopiujesz zawartość folderu na NAS, np.:
rsync -av ./example.com/ user@nas:/mnt/web/
#
##
