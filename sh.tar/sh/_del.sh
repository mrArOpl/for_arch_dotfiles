## skrypcior nizej kasuje podane w parametrach pliki/katalogi (rekurencyjnie) przy uzyciu shred'a z parametrem -u
#!/bin/bash
if [ $# = 0 ]
then
        echo "$0: musisz podac w parametrze plik lub katalog, który chcesz wymazac"
        exit 1
else
        for i in $*
        do
                if [ -f $i ]
                then
                        find $i -type f -exec bash -c 'shred -u {}' \;
                        echo "$0: $i zostal bezpiecznie skasowany"

                elif [ -d $i ]
                then
                        find $i -type f -exec bash -c 'shred -u {}' \;
                        rm -rfd $i
                        echo "$0: $i zostal bezpiecznie skasowany"

                else
                        echo "$0: podany plik/katalog: $i nie istnieje "
                        exit 1
                fi
        done
## end as(c)2019
