#!/bin/bash

# Ścieżka do katalogu z backupem
BACKUP_DIR="$HOME/xfce-theme-backup"

# Lista katalogów i plików do backupu
CONFIG_FILES=(
  "$HOME/.config/xfce4"
  "$HOME/.config/gtk-3.0"
  "$HOME/.gtkrc-2.0"
  "$HOME/.icons"
  "$HOME/.themes"
  "$HOME/.fonts"
  "$HOME/.config/fontconfig"
)

# Tworzenie katalogu backupu
mkdir -p "$BACKUP_DIR"

# Kopiowanie plików i katalogów
for path in "${CONFIG_FILES[@]}"; do
  if [ -e "$path" ]; then
    echo "Kopiuję: $path"
    cp -a "$path" "$BACKUP_DIR/"
  else
    echo "Pomijam (nie znaleziono): $path"
  fi
done

echo "✅ Backup zakończony. Znajduje się w: $BACKUP_DIR"

