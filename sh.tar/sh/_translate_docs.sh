#!/bin/bash
# ArO + AI — mirror + tłumacz offline EN→PL dla dokumentacji IPFire

SRC="www.ipfire.org/docs"
DST="docs-pl"

mkdir -p "$DST"

find "$SRC" -type f -name "*.html" | while read file; do
    out="${DST}/${file#$SRC/}"
    mkdir -p "$(dirname "$out")"

    echo "[*] Tłumaczenie: $file → $out"

    # tłumaczenie przez translate-shell (EN → PL)
    trans -b en:pl < "$file" > "$out"
done

echo "[+] Gotowe, bracie. Masz pełną dokumentację PL w: $DST"

