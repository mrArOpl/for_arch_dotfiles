#!/bin/bash
# _loopback_proxy_chain.sh by ArO & OG-AI
# 🔁 OG-script do szybkiego ustawienia łańcucha proxy z użyciem loopback (127.0.0.1)
# Wspiera HTTP, HTTPS, SOCKS5 i przekierowania lokalne via socat/iptables
# Idealny do testów, stealth proxy, pentestów i konfiguracji labów 🧠

## === ZMIENNE KONFIGURACYJNE ===
# Zmienna PROXY_TYPE: socks5 | http
PROXY_TYPE="socks5"
# Port na lokalnym loopbacku, który wystawimy
LOCAL_PORT=8888
# Proxy zewnętrzne (może być datacenter lub ISP)
EXTERNAL_PROXY_IP="1.2.3.4"
EXTERNAL_PROXY_PORT="3214"  # domyślnie SOCKS5
# Login i hasło do proxy
PROXY_USER="twoj_user"
PROXY_PASS="twoje_haslo"

## === OG: Przekieruj localhost na zewnętrzne proxy przez socat ===
echo "[*] Tworzę lokalny tunel na 127.0.0.1:$LOCAL_PORT → $EXTERNAL_PROXY_IP:$EXTERNAL_PROXY_PORT ($PROXY_TYPE)"

if [[ "$PROXY_TYPE" == "socks5" ]]; then
    socat TCP4-LISTEN:$LOCAL_PORT,fork,reuseaddr             PROXY:$EXTERNAL_PROXY_IP:google.com:$EXTERNAL_PROXY_PORT,socksport=$EXTERNAL_PROXY_PORT,proxyauth=$PROXY_USER:$PROXY_PASS &
elif [[ "$PROXY_TYPE" == "http" ]]; then
    socat TCP4-LISTEN:$LOCAL_PORT,fork,reuseaddr             PROXY:$EXTERNAL_PROXY_IP:google.com:$EXTERNAL_PROXY_PORT,proxyauth=$PROXY_USER:$PROXY_PASS &
else
    echo "[!] Nieznany typ proxy: $PROXY_TYPE"
    exit 1
fi

echo "[✓] Proxy chain ready! Teraz łącz się przez 127.0.0.1:$LOCAL_PORT z przeglądarki lub curl"
echo "    Przykład: curl -x $PROXY_TYPE://127.0.0.1:$LOCAL_PORT https://ifconfig.me"

# OG Komentarze:
# - socat: przekierowuje port lokalny na proxy przez TCP
# - można łączyć z proxychains, foxyproxy, curl, firefox itp.
# - przydatne do lokalnego tunelowania lub maskowania ruchu
# - po rozłączeniu: pkill socat

# Koniec gry.
