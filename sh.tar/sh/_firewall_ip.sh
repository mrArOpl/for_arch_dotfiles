#!/bin/bash

# Ścieżka do pliku z dozwolonymi adresami IP
IP_ALLOW_LIST="ipallow.txt"

# Resetowanie wszystkich reguł
iptables -F
iptables -X
iptables -Z
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# Całkowite zablokowanie IPv6
ip6tables -F
ip6tables -X
ip6tables -Z
ip6tables -P INPUT DROP
ip6tables -P FORWARD DROP
ip6tables -P OUTPUT DROP

# Zezwolenie na ruch na lokalnym interfejsie (localhost)
iptables -A INPUT -i lo -j ACCEPT

# Zezwolenie na ruch związany z już nawiązanymi połączeniami
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

# Zezwolenie na ruch związany z siecią lokalną
# iptables -A INPUT -s 192.168.1.0/24 -j ACCEPT

# Dodanie dozwolonych adresów IP z pliku
if [ -f "$IP_ALLOW_LIST" ]; then
    while IFS= read -r ip; do
        # Pomijanie pustych linii i komentarzy
        if [[ ! -z "$ip" && "$ip" != "#"* ]]; then
            iptables -A INPUT -s "$ip" -j ACCEPT
        fi
    done < "$IP_ALLOW_LIST"
fi

# Blokowanie reszty ruchu
iptables -A INPUT -j DROP

echo "Firewall skonfigurowany. IPv6 całkowicie zablokowane. IPv4 dozwolone tylko dla IP z listy."

