#!/bin/bash
#
#     Presantation Solution !
#
clear
echo ''
echo 'Inwiligacja' | toilet --metal -W
sleep 2s
clear
echo ''
echo 'Inwiligacja' | toilet --rainbow -W
sleep 2s
clear
echo ''
echo 'Inwiligacja' | toilet -W
sleep 2s
clear
echo ''
echo ' Pegasus ! ' | toilet --metal -W
sleep 2s
clear
echo ' Pegasus ! ' | toilet -W
sleep 2s
clear
echo ' Pegasus ! ' | toilet --rainbow -W
sleep 2s
clear
echo ''
echo ' Virusy ! ' | toilet --rainbow -W
sleep 2s
clear
echo ''
echo ' Virusy ! ' | toilet -W
sleep 2s
clear
echo ''
echo ' Virusy ! ' | toilet --metal -W
sleep 2s
clear
echo ''
echo ' Virusy ! ' | toilet -W
sleep 2s
clear
echo ''
echo ' Panica ! ' | toilet -W
sleep 1s
clear
echo ''
echo ' Panica ! ' | toilet --rainbow -W
sleep 1s
clear
echo ''
echo ' Panica ! ' | toilet -W
clear
echo ''
echo ' Panica ! ' | toilet --metal -W
sleep 1s
clear
echo ''
echo ' Lekarswo ' | toilet -W
sleep 1s
clear
echo ''
echo ' Lekarswo ' | toilet --metal -W
sleep 1s
clear
echo ''
echo ' Lekarswo ' | toilet -W
sleep 1s
clear
echo '  + + +  '
echo 'Paranoic   Linux' | figlet -W
sleep 1s
clear
echo ' + + +  '
echo 'Paranoic   Linux' | figlet -W
sleep 1s
clear
echo '  + + +  '
echo 'Paranoic   Linux' | figlet -W
sleep 1s
echo '    + + +  '
echo 'Paranoic   Linux' | figlet -W
sleep 1s
