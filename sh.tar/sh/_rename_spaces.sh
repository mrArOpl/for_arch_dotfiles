#!/bin/bash

# Sprawdzenie, czy skrypt uruchomiono z opcją --r
if [[ "$1" == "--r" ]]; then
    search_path="**/*"  # Szukaj rekurencyjnie
else
    search_path="*"  # Tylko bieżący katalog
fi

# Włącz obsługę globstar (dla rekursywnego wyszukiwania)
shopt -s globstar 2>/dev/null

# Zamiana spacji na podkreślenia w plikach i folderach
for file in $search_path; do
    if [[ "$file" == *" "* ]]; then
        new_name="${file// /_}"
        if [[ "$file" != "$new_name" ]]; then
            mv -v "$file" "$new_name"
        fi
    fi
done

echo "✅ Zamiana spacji na podkreślenia zakończona!"

