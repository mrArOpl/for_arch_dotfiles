#!/bin/bash

### BEGIN INIT INFO
#
#  Skrypt: _drop6ip
#
### END INIT INFO

# CZYSZCZENIE STARYCH REGUŁ IP6
ip6tables -F
ip6tables -Z
ip6tables -X
ip6tables -F -t nat
ip6tables -X -t nat
ip6tables -Z -t nat
ip6tables -F -t filter
ip6tables -X -t filter
ip6tables -Z -t filter
ip6tables -F -t mangle
ip6tables -X -t mangle
ip6tables -Z -t mangle

# USTAWIENIE DROP 6
ip6tables -P INPUT DROP
ip6tables -P FORWARD DROP
ip6tables -P OUTPUT DROP

#
echo "ip6tables ip6:"
ip6tables -S
