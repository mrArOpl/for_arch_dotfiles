#!/bin/bash

# Sprawdzenie, czy plik install.txt istnieje
if [ ! -f install.txt ]; then
    echo "Plik install.txt nie istnieje!"
    exit 1
fi

# Aktualizacja listy pakietów
sudo apt update

# Instalacja programów z listy
while IFS= read -r package || [ -n "$package" ]; do
    # Pominięcie pustych linii i komentarzy
    if [[ -z "$package" || "$package" == \#* ]]; then
        continue
    fi

    echo "Instaluję: $package"
    sudo apt install -y "$package"

done < install.txt

echo "Instalacja zakończona."