#!/usr/bin/env bash
# _clone_user_xfce.sh
# Clone an existing Manjaro/XFCE user into a new user:
# - creates target user (optionally)
# - rsync home with preserved attrs
# - fixes ownership
# - cleans session/cache junk
# - "safe clone" mode excludes secrets + browser profiles etc.
#
# Usage examples:
#   sudo ./_clone_user_xfce.sh --src aro --dst aro2 --create-user --safe --dry-run
#   sudo ./_clone_user_xfce.sh --src aro --dst aro2 --create-user --safe
#   sudo ./_clone_user_xfce.sh --src aro --dst aro2 --create-user --full
#
# Notes:
# - SAFE mode: best for "same look & apps config" without cloning secrets
# - FULL mode: copies (almost) everything - use only if you know what you're doing

set -euo pipefail

# ---------- defaults ----------
MODE="safe"          # safe | full
CREATE_USER=0
DRY_RUN=0
SHELL_PATH="/bin/bash"
HOME_BASE="/home"
RSYNC_BIN="$(command -v rsync || true)"

# ---------- helpers ----------
die() { echo "[-] $*" >&2; exit 1; }
ok()  { echo "[+] $*"; }
warn(){ echo "[!] $*" >&2; }

need_root() {
  [[ ${EUID:-$(id -u)} -eq 0 ]] || die "Run as root: sudo $0 ..."
}

usage() {
  cat <<EOF
Usage:
  $0 --src <user> --dst <user> [--create-user] [--safe|--full] [--dry-run]
Options:
  --src USER        source username (must exist)
  --dst USER        target username (can exist or be created)
  --create-user     create target user if not exists
  --safe            safe clone (default): excludes secrets, browsers, keyrings, ssh, gpg, etc.
  --full            full clone: copies almost everything (still cleans cache/session files)
  --dry-run         show what would be copied (rsync dry run)
  --shell PATH      shell for created user (default: /bin/bash)
  --home-base DIR   base home dir (default: /home)
Examples:
  sudo $0 --src aro --dst aro2 --create-user --safe --dry-run
  sudo $0 --src aro --dst aro2 --create-user --safe
  sudo $0 --src aro --dst aro2 --create-user --full
EOF
}

user_exists() { id "$1" &>/dev/null; }

# ---------- parse args ----------
SRC=""
DST=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --src) SRC="${2:-}"; shift 2;;
    --dst) DST="${2:-}"; shift 2;;
    --create-user) CREATE_USER=1; shift;;
    --safe) MODE="safe"; shift;;
    --full) MODE="full"; shift;;
    --dry-run) DRY_RUN=1; shift;;
    --shell) SHELL_PATH="${2:-}"; shift 2;;
    --home-base) HOME_BASE="${2:-}"; shift 2;;
    -h|--help) usage; exit 0;;
    *) die "Unknown option: $1 (use --help)";;
  esac
done

# ---------- checks ----------
need_root
[[ -n "$RSYNC_BIN" ]] || die "rsync not found. Install: sudo pacman -S rsync"
[[ -n "$SRC" && -n "$DST" ]] || { usage; exit 1; }

user_exists "$SRC" || die "Source user does not exist: $SRC"

SRC_HOME="$HOME_BASE/$SRC"
DST_HOME="$HOME_BASE/$DST"

[[ -d "$SRC_HOME" ]] || die "Source home not found: $SRC_HOME"

if user_exists "$DST"; then
  ok "Target user exists: $DST"
else
  if [[ $CREATE_USER -eq 1 ]]; then
    ok "Creating user: $DST"
    useradd -m -d "$DST_HOME" -s "$SHELL_PATH" "$DST"
    passwd "$DST" || true
  else
    die "Target user does not exist: $DST. Use --create-user to create it."
  fi
fi

[[ -d "$DST_HOME" ]] || die "Target home not found: $DST_HOME"

# avoid accidental self-clone
[[ "$SRC" != "$DST" ]] || die "SRC and DST must be different users."

# ---------- build rsync excludes ----------
# SAFE mode excludes:
# - ssh/gpg keys, keyrings, dbus tokens, xauth, browser profiles/cookies, etc.
# - caches
# - some app-specific secrets
SAFE_EXCLUDES=(
  "--exclude=.ssh/"
  "--exclude=.gnupg/"
  "--exclude=.pki/"
  "--exclude=.local/share/keyrings/"
  "--exclude=.local/share/kwalletd/"
  "--exclude=.kde/share/apps/kwallet/"
  "--exclude=.config/kwalletd/"
  "--exclude=.password-store/"
  "--exclude=.config/keepassxc/"
  "--exclude=.mozilla/"
  "--exclude=.config/google-chrome/"
  "--exclude=.config/chromium/"
  "--exclude=.config/BraveSoftware/"
  "--exclude=.config/vivaldi/"
  "--exclude=.config/opera/"
  "--exclude=.config/Microsoft/"
  "--exclude=.config/Slack/"
  "--exclude=.config/discord/"
  "--exclude=.config/Signal/"
  "--exclude=.config/session/"
  "--exclude=.config/TelegramDesktop/"
  "--exclude=.local/share/TelegramDesktop/"
  "--exclude=.local/share/torbrowser/"
  "--exclude=.config/torbrowser/"
  "--exclude=.local/share/Steam/"
  "--exclude=.steam/"
  "--exclude=.local/share/Trash/"
  "--exclude=.cache/"
  "--exclude=.dbus/"
  "--exclude=.ICEauthority"
  "--exclude=.Xauthority"
  "--exclude=.xauth*"
  "--exclude=.recently-used.xbel"
  "--exclude=.bash_history"
  "--exclude=.zsh_history"
  "--exclude=.wget-hsts"
  "--exclude=.lesshst"
  "--exclude=.python_history"
  "--exclude=.viminfo"
  "--exclude=.nv/"
  "--exclude=.config/autostart/"  # optional: autostart entries can be messy; comment out if you want them
)

# FULL mode: minimal excludes (still avoid trash/cache/session tokens)
FULL_EXCLUDES=(
  "--exclude=.cache/"
  "--exclude=.dbus/"
  "--exclude=.ICEauthority"
  "--exclude=.Xauthority"
  "--exclude=.xauth*"
  "--exclude=.local/share/Trash/"
)

EXCLUDES=()
if [[ "$MODE" == "safe" ]]; then
  EXCLUDES=("${SAFE_EXCLUDES[@]}")
  ok "Mode: SAFE (excludes secrets + browsers + history etc.)"
else
  EXCLUDES=("${FULL_EXCLUDES[@]}")
  ok "Mode: FULL (copies almost everything; still excludes cache/session junk)"
fi

# ---------- rsync flags ----------
RSYNC_FLAGS=(
  "-aAX"            # archive + ACL + xattrs
  "--numeric-ids"   # keep uid/gid numbers during copy; we will chown after
  "--info=progress2"
  "--delete"        # make dst mirror of src (careful)
)

if [[ $DRY_RUN -eq 1 ]]; then
  RSYNC_FLAGS+=("--dry-run")
  warn "DRY-RUN enabled: no changes will be made by rsync."
fi

# ---------- do copy ----------
ok "Cloning: $SRC_HOME/  ->  $DST_HOME/"
# trailing slashes are important!
rsync "${RSYNC_FLAGS[@]}" "${EXCLUDES[@]}" "$SRC_HOME/" "$DST_HOME/"

# ---------- ownership fix ----------
if [[ $DRY_RUN -eq 0 ]]; then
  ok "Fixing ownership: chown -R $DST:$DST $DST_HOME"
  chown -R "$DST:$DST" "$DST_HOME"

  # ---------- cleanup junk (extra safety) ----------
  ok "Cleaning session/cache leftovers in $DST_HOME"
  rm -rf "$DST_HOME/.cache/"* 2>/dev/null || true
  rm -rf "$DST_HOME/.dbus" 2>/dev/null || true
  rm -rf "$DST_HOME/.ICEauthority" "$DST_HOME/.Xauthority" "$DST_HOME/.xauth"* 2>/dev/null || true

  # Some XFCE session state can be user-specific; optional wipe:
  # It can help avoid "phantom panels" after clone. Uncomment if needed.
  # rm -rf "$DST_HOME/.cache/sessions" 2>/dev/null || true

  ok "Done."
  ok "Tip: log out/in as $DST to let XFCE regenerate per-user session bits."
else
  ok "Dry-run complete."
  ok "If it looks good, rerun without --dry-run."
fi

exit 0

