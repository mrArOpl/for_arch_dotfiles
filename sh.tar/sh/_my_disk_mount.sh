#!/bin/bash
#
mount /dev/sdb2 /home/linuxlite/linux_share/1000Gb
mount /dev/nvme0n1p1 /home/linuxlite/linux_share/nvme200gb

# before create dir, and mount real disks on linux lite, to share smb://192.168.33.xx/linux_share
# in /etc/samba is 2 config file, 1 - user:pass (linuxlite:linuxlite)  2 - smb.conf : set WORKGROUP  etc...