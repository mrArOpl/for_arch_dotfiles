#!/bin/bash
#
# ArO (c)2024 VPN IPFire creator
#             ExpressVPN,You creat special 2 files
#
clear
echo ' ArO (c)2024 VPN IPFire creator'
echo ' ExpressVPN,You creat special 2 files'
echo ' ------------------------------------'
echo ' Please Password _ '
read PASSZIPVPN  # for secure, use min. 16 chart pass for encrypt, finallcrypt good.
ip a
cd /
cd var
ls
cd ipfire
ls
cd ovpn
ls
mkdir -p /dev/net
mknod /dev/net/tun c 10 200
chmod 600 /dev/net/tun
cat /dev/net/tun
ls
iptables -t nat -A POSTROUTING -s 192.168.0.0/24 -o tun0 -j MASQUERADE
openvpn expressvpn_pl_udp.ovpn   # prepare file 
###
# End , Now close terminal and connection, good idea wifi hotspot, Buy UPS
# IPFire not problem, if hardware ok. then nonstop run.
# ArO (c)2024
