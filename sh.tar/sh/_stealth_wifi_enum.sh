#!/bin/bash
# stealth_wifi_enum.sh – cichy rekonesans WiFi z anonimizacją
# autor: ArO + ChatGPT OG Style

iface="wlan0"           # Zmień na swoje (np. wlan0mon)
subnet="192.168.1.0/24" # W zależności od sieci
export_dir="/tmp/wifi_recon"

# 🔧 Kolory (dla stylu)
RED='\033[0;31m'; GREEN='\033[0;32m'; NC='\033[0m'

echo -e "${GREEN}[+] Uruchamiam cichy tryb rekonesansu...${NC}"

# 1. Losowy MAC + hostname
echo -e "${GREEN}[+] Randomizacja MAC + hostname...${NC}"
sudo ip link set $iface down
sudo macchanger -r $iface
sudo hostnamectl set-hostname anon$(shuf -i 1000-9999 -n 1)
sudo ip link set $iface up
sleep 2

# 2. Tworzymy katalog
mkdir -p "$export_dir"
timestamp=$(date +%Y-%m-%d_%H-%M)

# 3. Skanowanie hostów cicho (slow scan)
echo -e "${GREEN}[+] Wykrywanie aktywnych hostów...${NC}"
sudo nmap -sn -T2 $subnet -oN "$export_dir/hosts_$timestamp.txt"

# 4. Dump pakietów DHCP + ARP do PCAP
echo -e "${GREEN}[+] Sniff DHCP/ARP (30 sekund)...${NC}"
sudo timeout 30s tcpdump -i $iface arp or port 67 or port 68 -w "$export_dir/sniff_$timestamp.pcap"

# 5. Zapis końcowy
echo -e "${GREEN}[✓] Zakończono. Pliki w: $export_dir${NC}"
ls -lh "$export_dir"

# 🧠 Opcjonalnie: parsowanie wyników (dorzucimy później?)
#
#
# OPIS:
#  Zmianę MAC + hostname (anonimizacja),
#  Skan hostów w sieci (cicho),
#  Dump ARP/DHCP do pliku .pcap,
#  Mapę urządzeń do pliku .txt,
#  Obsługę opóźnień (anti-IDS),
#  Możliwość eksportu wyniku do np. /ramdisk/wifi_recon/
#
