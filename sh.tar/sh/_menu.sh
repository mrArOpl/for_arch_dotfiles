#!/bin/bash
###########
#
#   (c)2024 ArO
#   _menu.sh
#
###########
clear
echo " .........................................................."
echo "     -= MENU-ArO(c)2024 =- "
date
echo " .........................................................."
cal
echo " .........................................................."
echo " -- alias -- lsblk -f -- df -a -- hostnamectl -- inxi -v7  "
read
echo " ThX - use commands ;-)  "
echo " .........................................................."
# _info koniec
###################################################################
# GNU bash, wersja 4.3.30(1)-release-(i586-pc-linux-gnu)
# Użycie:	bash [długa opcja GNU] [opcja] ...
#	bash [długa opcja GNU] [opcja] plik-skryptu ... Długie opcje GNU:
#	--debug
#	--debugger
#	--dump-po-strings
#	--dump-strings
#	--help
#	--init-file
#	--login
#	--noediting
#	--noprofile
#	--norc
#	--posix
#	--rcfile
#	--restricted
#	--verbose
#	--version
#	Opcje powłoki:
#	-ilrsD lub -c polecenie lub -O shopt_option		(tylko wywołanie)
#	-abefhkmnptuvxBCHP lub -o 
#	opcja Aby uzyskać więcej 
#	informacji o opcjach 
#	powłoki, napisz `bash -c "help set"'.
#	Aby uzyskać 
#	więcej informacji o 
#	poleceniach wewnętrznych 
#	powłoki, napisz `bash -c help'. 
#	Do zgłaszania błędów 
#	należy używać polecenia 
#	`bashbug'
#
#######
