#!/bin/bash
#########################################################################
##                                                                     ##
##   ArO (c)2023 02.01.2024  # Install software EndeavourOS (Arch)     ##
##   Running: sudo ./_archsoft.sh                                      ##
##                                                                     ##
#########################################################################
clear
echo ' '
echo ' --------------------------------------------------- '
echo ' START INSTALL ArO SOFTWARE APLICATIONS ARCH LINUX ! '
echo ' PRESS ANY KEY '; read
echo ' '
pacman -Sy
# pacman -S hplip                                                                      # if not instalator
# pacman -Syu cups cups-browsed cups-filters cups-pdf system-config-printer --needed   # if not instalator 
# systemctl enable --now cups.service                                                  #  hp-setup -i (i=cli)
pacman -S veracrypt
pacman -S firetools doublecmd-gtk2 terminator tilix gnome-disk-utility       # sandboxing ! greate utility
pacman -S pluma gedit geany caja bluefish                                    # editors
pacman -S bitwarden gnote chromium abiword xpad                              # passmanager!  
pacman -S mc mtr iftop htop btop nmap neofetch                               # net tools
pacman -S vlc parole smplayer                                                # video players
pacman -S vokoscreen ristretto krita pinta mat2                              # screen recording ! 
pacman -S seahorse keepassxc
pacman -S xpdf atril evince okular xreader
pacman -S speedtest-cli falkon vivaldi nload netsurf
pacman -S gparted partitionmanager
pacman -S fuseiso wit                                                        # iso tools
pacman -S bleachbit
# pacman -S gpg-crypter fscrypt gnugpg2   # check
#
echo ' --------------------------------------------------- '
echo ' end -= ArO =- '
## end

# [as@os-3050 ~]$ id
# uid=1000(as) gid=1000(as) grupy=1000(as),3(sys),981(rfkill),984(users),998(wheel)
# usermod -aG users as
## end
