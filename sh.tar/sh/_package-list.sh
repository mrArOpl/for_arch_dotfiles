#!/bin/bash

pacman -Qq > pkg.list
paclist core > core.list
paclist extra > extra.list
paclist multilib > multilib.list
pacman -Qem > archlinuxfr.list

echo
echo "         done"
