#!/usr/bin/env bash
#
# _probe_analyzer.sh
# Prosty analizator "Probe Requests" z pliku CSV airodump-ng
# Użycie:
#   ./_probe_analyzer.sh probes_log-01.csv
#
# Działa wyłącznie analitycznie – nic nie nadaje, nic nie atakuje.
# Możesz tego używać do:
#   - sprawdzenia, jakie SSID szukają klienci w Twojej okolicy
#   - weryfikacji, czy Twoje własne urządzenia nie spamują starych sieci
#   - edukacji i analizy ryzyka "evil twin" (po stronie defensywnej)

set -euo pipefail

if [[ $# -lt 1 ]]; then
    echo "Użycie: $0 plik_airodump.csv"
    exit 1
fi

CSV_FILE="$1"

if [[ ! -f "$CSV_FILE" ]]; then
    echo "ERROR: Nie ma pliku: $CSV_FILE"
    exit 1
fi

echo "==[ Analiza Probe Requests z: $CSV_FILE ]=="
echo

# 1) Wyciągnięcie sekcji klientów z pliku CSV
# Airodump-ng oddziela AP i stacje pustą linią.
# Klienci są poniżej pustej linii, nagłówki zaczynają się od "Station MAC".
TMP_CLIENTS="$(mktemp)"

awk '
BEGIN { in_clients=0 }
# Pusta linia przełącza sekcję
/^$/ { if (in_clients==0) { in_clients=1; next } }
# Gdy jesteśmy w sekcji klientów i mamy nagłówek lub dane:
in_clients==1 { print }
' "$CSV_FILE" > "$TMP_CLIENTS"

if ! grep -q "Station MAC" "$TMP_CLIENTS"; then
    echo "Nie udało się znaleźć sekcji klientów w pliku CSV."
    rm -f "$TMP_CLIENTS"
    exit 1
fi

echo "==[ Lista klientów + szukane SSID (Probes) ]=="
echo

# 2) Wypisanie tabelki: MAC | Probes
# W CSV kolumny są rozdzielone przecinkami, Probes jest zazwyczaj ostatnią kolumną.
# Ignorujemy nagłówek "Station MAC".
awk -F',' '
/^Station MAC/ { next }
{
    mac=$1
    probes=$NF
    # Trim spacje
    gsub(/^ +| +$/, "", mac)
    gsub(/^ +| +$/, "", probes)
    if (mac != "" && probes != "") {
        printf "%-20s -> %s\n", mac, probes
    }
}
' "$TMP_CLIENTS"

echo
echo "==[ Top 15 najczęściej szukanych SSID (Probes) ]=="
echo

# 3) Statystyka SSID z kolumny Probes
# Rozbijamy wpisy po przecinku (bo jeden klient może szukać wielu SSID naraz).
awk -F',' '
/^Station MAC/ { next }
{
    probes=$NF
    # Usuwamy spacje z początku/końca
    gsub(/^ +| +$/, "", probes)
    if (probes != "") {
        n = split(probes, arr, /[;,:]/)
        for (i=1; i<=n; i++) {
            ssid=arr[i]
            gsub(/^ +| +$/, "", ssid)
            gsub(/ +$/, "", ssid)
            if (ssid != "") {
                counts[ssid]++
            }
        }
    }
}
END {
    for (s in counts) {
        printf "%5d  %s\n", counts[s], s
    }
}
' "$TMP_CLIENTS" | sort -rn | head -n 15

rm -f "$TMP_CLIENTS"

echo
echo "Gotowe. To jest czysto pasywna analiza Probes."
echo "Używaj tego, żeby ogarniać, jakie SSID Twoje i cudze urządzenia wołają w eter."
#
#

