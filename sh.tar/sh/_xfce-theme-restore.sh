#!/bin/bash

# Ścieżka do katalogu backupu (zmień jeśli przenosisz z USB czy z innej lokalizacji)
BACKUP_DIR="$HOME/xfce-theme-backup"

# Lista katalogów i plików do przywrócenia
CONFIG_FILES=(
  "xfce4"
  "gtk-3.0"
  ".gtkrc-2.0"
  ".icons"
  ".themes"
  ".fonts"
  "fontconfig"
)

# Przywracanie
for item in "${CONFIG_FILES[@]}"; do
  SRC="$BACKUP_DIR/$item"
  if [ -e "$SRC" ]; then
    DEST="$HOME/.config/$item"
    [ "$item" = ".gtkrc-2.0" ] && DEST="$HOME/.gtkrc-2.0"
    [ "$item" = ".icons" ] && DEST="$HOME/.icons"
    [ "$item" = ".themes" ] && DEST="$HOME/.themes"
    [ "$item" = ".fonts" ] && DEST="$HOME/.fonts"

    # Tworzenie kopii zapasowej, jeśli już istnieje
    if [ -e "$DEST" ]; then
      mv "$DEST" "${DEST}.bak_$(date +%s)"
      echo "🔄 Stara wersja przeniesiona do: ${DEST}.bak_*"
    fi

    echo "▶ Przywracam: $SRC → $DEST"
    cp -a "$SRC" "$DEST"
  else
    echo "⚠ Nie znaleziono w backupie: $SRC"
  fi
done

echo "✅ Przywracanie zakończone. Wyloguj się i zaloguj ponownie lub uruchom: xfce4-panel --restart"

