#!/bin/bash
#
clear
echo ' Dystrybucja Manjaro - ParanoicOS & NovaOS  '
echo ' ParanoicOS - DNSCrypt2 & VPN & PROXY & Mullvad  '
echo ' Proton VPN, Disk, Mail, PassManager & TutaNota '
echo ' TOR & i2p, LibreWolf, Brave, Floorp '
echo ' Nowe aliasy, AppImage, Skrypty sh i py '
echo ' Prompt - color ParrotOS styl, ip & time  '
echo ' -------------------------------------------------- '
echo ' Autor: ArO , dr.code@tuta.io , https://mr-aro.site '
read
# cd /home/admm/Documents/parrot4_1/komendy
# ls -acl

# end
