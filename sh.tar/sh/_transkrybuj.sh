#!/bin/bash
# nagrywa 10 sekund, transkrybuje i tworzy .txt oraz .srt

echo "🔴 Nagrywanie 10 sekund z mikrofonu..."
arecord -f cd -t wav -d 10 -r 16000 nagranie.wav

echo "🎧 Transkrypcja z użyciem Whisper.cpp..."
./main -m models/ggml-base.pl.bin -f nagranie.wav -otxt -osrt

echo "✅ Gotowe. Pliki: nagranie.txt i nagranie.srt"

