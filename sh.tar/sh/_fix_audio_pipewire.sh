#!/bin/bash
# _fix_audio_pipewire.sh - OG Reanimacja audio przez PipeWire by ArO & AI

LOGFILE="/tmp/pipewire_fix_$(date +%Y%m%d_%H%M%S).log"

banner() {
    echo -e "\n\033[1;36m=== Reanimacja PipeWire Audio System ===\033[0m"
}
if [ -z "$XDG_RUNTIME_DIR" ] || [ -z "$DBUS_SESSION_BUS_ADDRESS" ]; then
    echo -e "\n❌ Brak aktywnej sesji użytkownika (XDG/DBUS)!"
    echo -e "   Nie uruchamiaj tego skryptu jako sudo/root."
    echo -e "   Wróć do sesji użytkownika i uruchom ponownie:\n"
    echo -e "   \033[1;32m./_fix_audio_pipewire.sh\033[0m"
    exit 1
fi

pause() {
    read -rp "Naciśnij ENTER, by kontynuować..."
}

log() {
    echo -e "$1" | tee -a "$LOGFILE"
}

cleanup_configs() {
    log "\n🧹 Czyszczenie konfiguracji użytkownika..."
    rm -rf ~/.config/pipewire ~/.local/state/pipewire ~/.config/wireplumber
    log "✔️ Usunięto stare configi PipeWire i WirePlumber."
}

reinstall_stack() {
    log "\n📦 Reinstalacja stacku audio (pipewire + wireplumber)..."
    sudo pacman -Syu --noconfirm pipewire pipewire-pulse pipewire-alsa pipewire-jack wireplumber gst-plugin-pipewire libpulse
    log "✔️ Zainstalowano pakiety."
}

enable_services() {
    log "\n🔧 Włączanie usług PipeWire..."
    systemctl --user daemon-reexec
    systemctl --user daemon-reload
    systemctl --user --now enable pipewire.socket pipewire.service
    systemctl --user --now enable pipewire-pulse.socket pipewire-pulse.service
    systemctl --user --now enable wireplumber.service
    log "✔️ Usługi uruchomione."
}

status_check() {
    log "\n📋 Status usług:"
    systemctl --user status pipewire.service | tee -a "$LOGFILE"
    systemctl --user status pipewire-pulse.service | tee -a "$LOGFILE"
    systemctl --user status wireplumber.service | tee -a "$LOGFILE"
    pactl info | tee -a "$LOGFILE"
}

test_audio() {
    log "\n🔊 Test audio (lewy/prawy kanał):"
    speaker-test -c2 -t wav | tee -a "$LOGFILE"
}

menu() {
    clear
    banner
    echo -e "\nWybierz opcję:"
    echo "1 - Wyczyść konfiguracje użytkownika PipeWire"
    echo "2 - Przeinstaluj stack audio (PipeWire + dodatki)"
    echo "3 - Włącz i zrestartuj usługi"
    echo "4 - Sprawdź status usług + info PulseAudio"
    echo "5 - Wykonaj test audio (głośniki)"
    echo "6 - Full reanimacja (1 → 3)"
    echo "0 - Wyjście"
}

while true; do
    menu
    read -rp $'\nTwoja opcja > ' opt
    case "$opt" in
        1) cleanup_configs && pause ;;
        2) reinstall_stack && pause ;;
        3) enable_services && pause ;;
        4) status_check && pause ;;
        5) test_audio && pause ;;
        6) cleanup_configs && reinstall_stack && enable_services && pause ;;
        0) echo -e "\n🚪 Zakończono. Log zapisany w $LOGFILE\n"; exit 0 ;;
        *) echo "❌ Nieznana opcja." && pause ;;
    esac
done

