#!/usr/bin/env bash
# _aro_partclone_backup_zstd.sh
# Autor: ArO + AI
# Opis: Robi skompresowany (zstd) obraz partycji używając partclone, kopiując tylko zajęte bloki.

set -euo pipefail

usage() {
    cat <<EOF
Użycie:
  sudo $0 /dev/SDXn [katalog_docelowy]

Przykład:
  sudo $0 /dev/nvme0n1p2 /backup

Jeśli katalog_docelowy nie zostanie podany, użyty będzie katalog bieżący.

Output:
  <dev>_<fstype>_YYYY-MM-DD_HH-MM.img.zst
  Np.: nvme0n1p2_ext4_2025-12-12_01-23.img.zst
EOF
    exit 1
}

# --- sprawdzenie roota ---
if [[ "${EUID}" -ne 0 ]]; then
    echo "⚠ Ten skrypt musi działać jako root (sudo)."
    exit 1
fi

# --- argumenty ---
if [[ $# -lt 1 || $# -gt 2 ]]; then
    usage
fi

SRC_DEV="$1"
DEST_DIR="${2:-$(pwd)}"

if [[ ! -b "${SRC_DEV}" ]]; then
    echo "❌ ${SRC_DEV} nie jest blokowym urządzeniem (np. /dev/sda1, /dev/nvme0n1p2)."
    exit 1
fi

# --- sprawdzenie zależności ---
for bin in partclone lsblk zstd; do
    if ! command -v "$bin" &>/dev/null; then
        echo "❌ Brak programu: $bin  (zainstaluj: sudo pacman -S $bin)"
        exit 1
    fi
done

mkdir -p "${DEST_DIR}"

# --- wykrycie systemu plików ---
FSTYPE="$(lsblk -no FSTYPE "${SRC_DEV}" | head -n 1 || true)"

if [[ -z "${FSTYPE}" ]]; then
    echo "❌ Nie udało się wykryć typu systemu plików dla ${SRC_DEV}."
    exit 1
fi

case "${FSTYPE}" in
    ext2|ext3|ext4)
        PARTCLONE_BIN="partclone.extfs"
        ;;
    btrfs)
        PARTCLONE_BIN="partclone.btrfs"
        ;;
    xfs)
        PARTCLONE_BIN="partclone.xfs"
        ;;
    f2fs)
        PARTCLONE_BIN="partclone.f2fs"
        ;;
    *)
        echo "❌ Nieobsługiwany typ systemu plików: ${FSTYPE}"
        echo "   Obsługiwane: ext2/3/4, btrfs, xfs, f2fs."
        exit 1
        ;;
esac

if ! command -v "${PARTCLONE_BIN}" &>/dev/null; then
    echo "❌ Brakuje binarki ${PARTCLONE_BIN}. Zainstaluj odpowiedni pakiet (partclone)."
    exit 1
fi

# --- nazwa pliku wyjściowego ---
BASE_DEV_NAME="$(basename "${SRC_DEV}")"
TS="$(date +%F_%H-%M)"
OUT_FILE="${DEST_DIR}/${BASE_DEV_NAME}_${FSTYPE}_${TS}.img.zst"
LOG_FILE="${OUT_FILE%.img.zst}.log"

echo "=== ArO + AI backup OG mode ==="
echo "Źródło:        ${SRC_DEV}"
echo "Typ FS:        ${FSTYPE}"
echo "Narzędzie:     ${PARTCLONE_BIN}"
echo "Katalog:       ${DEST_DIR}"
echo "Plik wyjściowy:${OUT_FILE}"
echo "Log:           ${LOG_FILE}"
echo "--------------------------------"

read -rp "Kontynuować backup? [tak/N]: " yn
yn="${yn,,}"
if [[ "${yn}" != "tak" && "${yn}" != "t" && "${yn}" != "y" ]]; then
    echo "Przerwano przez użytkownika."
    exit 1
fi

# --- info: lepiej nie montować partycji podczas backupu ---
MOUNTED="$(lsblk -no MOUNTPOINT "${SRC_DEV}" || true)"
if [[ -n "${MOUNTED}" ]]; then
    echo "⚠ UWAGA: Partycja ${SRC_DEV} jest zamontowana w: ${MOUNTED}"
    echo "   Najbezpieczniej wykonać backup z live-USB albo po odmontowaniu."
    read -rp "Robić backup mimo to? [tak/N]: " yn2
    yn2="${yn2,,}"
    if [[ "${yn2}" != "tak" && "${yn2}" != "t" && "${yn2}" != "y" ]]; then
        echo "Przerwano przez użytkownika."
        exit 1
    fi
fi

echo ">>> Start backupu: $(date)" | tee "${LOG_FILE}"

# --- właściwy backup: partclone -> zstd ---
# partclone wypisuje surowy obraz na STDOUT, który kompresujemy zstd
# -T0 = użyj wszystkich rdzeni, -19 = mocna kompresja
set -o pipefail
if "${PARTCLONE_BIN}" -c -s "${SRC_DEV}" 2>&1 | tee -a "${LOG_FILE}" | zstd -T0 -19 -o "${OUT_FILE}"; then
    echo ">>> Backup zakończony OK: $(date)" | tee -a "${LOG_FILE}"
    echo "✅ Gotowe. Plik: ${OUT_FILE}"
else
    echo "❌ Błąd podczas backupu – sprawdź log: ${LOG_FILE}"
    exit 1
fi

