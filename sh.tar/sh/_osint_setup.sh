#!/bin/bash

# =========================
# OSINT Quick Setup Script
# By: ChatGPT & You 💻
# =========================
# Jasne! Oto skrypt osint-quicksetup.sh, który:
#
# Tworzy strukturę katalogów pod OSINT
# Instaluje popularne narzędzia z APT
# Pobiera kluczowe narzędzia z GitHub
# Jest modularny i gotowy do rozbudowy
echo "[*] Tworzenie struktury katalogów OSINT..."
mkdir -p ~/osint/{tools,reports,screenshots,data,wordlists,profiles}

echo "[*] Instalacja narzędzi z APT..."
sudo apt update
sudo apt install -y theharvester spiderfoot recon-ng sherlock \
  phoneinfoga holehe sublist3r git-dumper whois \
  dnsrecon dnsenum exiftool curl wget jq nmap

echo "[*] Klonowanie wybranych repozytoriów z GitHub..."

cd ~/osint/tools

# GHunt – Google OSINT
git clone https://github.com/mxrch/GHunt.git

# Twint – Twitter scraper (uwaga: może wymagać starszego Pythona lub poprawek)
git clone https://github.com/twintproject/twint.git

# Social Analyzer – multi-source user checker
git clone https://github.com/qeeqbox/social-analyzer.git

# Pompem – CVE/exploit search
git clone https://github.com/r3nt0n/pompem.git

# Email2phonenumber (soczjo)
git clone https://github.com/martinvigo/email2phonenumber.git

echo "[*] Instalacja zależności Pythona (opcjonalnie, zrób to w venv)..."

echo "[+] Gotowe. Katalog ~/osint zawiera:"
tree ~/osint -L 2

echo ""
echo "[✔] OSINT starter kit zainstalowany. Przejrzyj ~/osint/tools i używaj z głową."
echo "    Pamiętaj: recon to tylko początek. Ty jesteś analizatorem."

