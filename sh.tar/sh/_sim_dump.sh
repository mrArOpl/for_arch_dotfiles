#!/bin/bash
# ver. 1.1 16.06.2025 04:38:58
# SIM Forensic Dump with pySIM + PIN + venv support
# Autor: ChatGPT + as

LOGFILE="sim-dump-$(date +%Y%m%d_%H%M%S).txt"
VENVDIR="./pysim/venv"

echo "[INFO] Szukam urządzeń ttyUSB..."
DEVICE=$(sudo dmesg | grep -o 'ttyUSB[0-9]\+' | tail -n1)
DEVICE="/dev/$DEVICE"

if [ ! -e "$DEVICE" ]; then
    echo "[ERROR] Nie znaleziono urządzenia ttyUSB. Czy czytnik jest podłączony?"
    exit 1
fi

echo "[INFO] Wykryto urządzenie: $DEVICE"

echo "[INFO] Sprawdzam reakcję na komendę AT..."
echo -e "AT\r" | sudo tee "$DEVICE" > /dev/null
sleep 1
ATRESPONSE=$(timeout 2 sudo cat "$DEVICE" | grep OK)

if [[ "$ATRESPONSE" == *"OK"* ]]; then
    echo "[OK] Czytnik odpowiada poprawnie na komendę AT."
else
    echo "[WARNING] Brak odpowiedzi na AT. Karta SIM może nie być włożona lub czytnik nie działa poprawnie."
fi

# Tworzenie katalogu logów
mkdir -p ~/sim_logs

# Klonowanie pySIM, jeśli nie istnieje
if [ ! -f "./pysim/pySim-read.py" ]; then
    echo "[INFO] Pobieram pySIM..."
    git clone https://github.com/osmocom/pysim.git
fi

# Tworzenie środowiska venv
if [ ! -d "$VENVDIR" ]; then
    echo "[INFO] Tworzę środowisko venv..."
    python -m venv "$VENVDIR"
    source "$VENVDIR/bin/activate"
    pip install -r ./pysim/requirements.txt
else
    source "$VENVDIR/bin/activate"
fi

# Zapytanie o PIN (opcjonalnie)
read -p "Jeśli karta ma PIN, podaj go (lub zostaw puste): " PIN

# Składanie komendy
CMD="python3 ./pysim/pySim-read.py --transport serial -d $DEVICE"

if [ ! -z "$PIN" ]; then
    CMD="$CMD -a $PIN"
fi

echo -e "\n\n========= SIM READ $(date) =========\n" >> "$LOGFILE"
echo "[INFO] Uruchamiam: $CMD" | tee -a "$LOGFILE"
eval "$CMD" | tee -a "$LOGFILE"

# Próba odczytu numeru telefonicznego z EF_MSISDN
echo "[INFO] Próba odczytu EF_MSISDN (numer telefonu)..."
python3 ./pysim/pySim-shell.py --transport serial -d "$DEVICE" <<EOF >> "$LOGFILE"
$([ -n "$PIN" ] && echo "verify_chv 1 $PIN")
select 6f40
read_binary
EOF

echo -e "[INFO] Zapisano dane do pliku: $LOGFILE"
cp "$LOGFILE" ~/sim_logs/
deactivate
