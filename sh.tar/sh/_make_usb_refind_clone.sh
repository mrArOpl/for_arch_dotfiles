#!/usr/bin/env bash
# _make_usb_refind_clone.sh — klon EFI (rEFInd/GRUB) na pendrive
# Autor: ArO + AI (OG)
# Użycie (BEZ formatowania):   sudo ./_make_usb_refind_clone.sh /dev/sdX1
# Użycie (Z formatowaniem):     sudo ./_make_usb_refind_clone.sh /dev/sdX --wipe
# Opcje:
#   --boot=refind|manjaro|kali|auto   (domyślnie: auto → rEFInd > Manjaro > Kali)
#   --label=USB_RESCUE_EFI            (etykieta FAT32; default: USB_RESCUE_EFI)
#   --efiboot                         (spróbuj dodać wpis UEFI przez efibootmgr)
#   --force                           (pomiń dodatkowe pytania)
#
# Wymagania: rsync, parted, lsblk, blkid, mkfs.vfat, efibootmgr (opcjonalnie)
#
# sudo ./_make_usb_refind_clone.sh /dev/sdX1   # sdX1 = partycja fat32, pendrive
#
#   info:  linux_administration_pl/Backup_efi_boot_to_USBootClone.pdf
#
set -euo pipefail

die(){ echo "ERROR: $*" >&2; exit 1; }
warn(){ echo "WARN: $*" >&2; }
info(){ echo "==> $*"; }

TARGET="${1:-}"
[[ -z "${TARGET}" ]] && die "Podaj cel: /dev/sdX1 (partycja) albo /dev/sdX (całe urządzenie z --wipe)"

# Domyślne opcje
BOOT_PREF="auto"
LABEL="USB_RESCUE_EFI"
DO_WIPE=false
ADD_EFIBOOT=false
FORCE=false

shift || true
while [[ $# -gt 0 ]]; do
  case "$1" in
    --boot=*) BOOT_PREF="${1#*=}"; shift;;
    --label=*) LABEL="${1#*=}"; shift;;
    --wipe) DO_WIPE=true; shift;;
    --efiboot) ADD_EFIBOOT=true; shift;;
    --force) FORCE=true; shift;;
    *) die "Nieznana opcja: $1";;
  esac
done

# Sprawdzenie zależności
need_bins=(rsync parted lsblk blkid mkfs.vfat)
for b in "${need_bins[@]}"; do command -v "$b" >/dev/null 2>&1 || die "Brak narzędzia: $b"
done
command -v efibootmgr >/dev/null 2>&1 || warn "efibootmgr brak — wpis UEFI nie będzie dodany (chyba że nie używasz --efiboot)"

# Wykryj źródłową partycję EFI
detect_src_efi(){
  local src=""
  # 1) Spróbuj /boot/efi
  src="$(findmnt -no SOURCE /boot/efi 2>/dev/null || true)"
  if [[ -n "$src" && -b "$src" ]]; then
    echo "$src"; return 0
  fi
  # 2) Szukaj po GUID typu EFI
  local GUID="c12a7328-f81f-11d2-ba4b-00a0c93ec93b"
  while read -r dev fstype parttype mp flags; do
    if [[ "$parttype" =~ $GUID ]] || [[ "$flags" =~ esp ]]; then
      echo "$dev"; return 0
    fi
  done < <(lsblk -pnlo NAME,FSTYPE,PARTTYPE,MOUNTPOINT,PARTFLAGS | grep -E "part")
  return 1
}

SRC_EFI="$(detect_src_efi || true)"
[[ -z "$SRC_EFI" ]] && die "Nie znalazłam partycji EFI źródła. Zamontuj /boot/efi lub upewnij się, że istnieje EFI."

info "Źródłowa EFI: $SRC_EFI"

# Rozpoznaj, czy TARGET to urządzenie (np. /dev/sdX) czy partycja (np. /dev/sdX1)
is_whole_disk=false
if [[ "$TARGET" =~ ^/dev/nvme[0-9]+n[0-9]+$ || "$TARGET" =~ ^/dev/sd[a-z]+$ || "$TARGET" =~ ^/dev/vd[a-z]+$ ]]; then
  is_whole_disk=true
fi

# Ostrzeżenia
if $is_whole_disk && ! $DO_WIPE ; then
  die "Podałeś całe urządzenie ($TARGET), ale bez --wipe. Dodaj --wipe albo wskaż partycję (np. /dev/sdX1)."
fi

if $is_whole_disk && ! $FORCE ; then
  echo "UWAGA: ZA CHWILĘ WYMAŻĘ CAŁE URZĄDZENIE: $TARGET (partycjonowanie GPT + FAT32)"
  read -r -p "Na pewno? wpisz: TAK  " ans
  [[ "$ans" == "TAK" ]] || die "Przerwano."
fi

# Przygotuj docelową partycję FAT32 ESP
if $is_whole_disk; then
  info "Tworzę GPT + EFI FAT32 na $TARGET..."
  umount "${TARGET}"* >/dev/null 2>&1 || true
  wipefs -a "$TARGET"
  parted -s "$TARGET" mklabel gpt
  parted -s "$TARGET" mkpart EFI fat32 1MiB 100%
  parted -s "$TARGET" set 1 esp on
  # Wyznacz nazwę partycji 1 (sdX1 / nvme0n1p1)
  if [[ "$TARGET" =~ ^/dev/nvme ]]; then
    DEST_PART="${TARGET}p1"
  else
    DEST_PART="${TARGET}1"
  fi
  mkfs.vfat -F32 -n "$LABEL" "$DEST_PART"
else
  DEST_PART="$TARGET"
  info "Używam istniejącej partycji docelowej: $DEST_PART"
  fstype=$(blkid -o value -s TYPE "$DEST_PART" || true)
  if [[ "$fstype" != "vfat" && "$fstype" != "fat32" ]]; then
    if $FORCE; then
      warn "Partycja nie jest FAT32 (jest: $fstype). Formatuję do FAT32..."
      mkfs.vfat -F32 -n "$LABEL" "$DEST_PART"
    else
      die "Partycja nie jest FAT32 (jest: $fstype). Uruchom z --force żeby sformatować do FAT32."
    fi
  fi
fi

# Montowanie i klon
SRC_MNT="/mnt/efi_src.$$"
DST_MNT="/mnt/efi_usb.$$"
mkdir -p "$SRC_MNT" "$DST_MNT"
mount "$SRC_EFI" "$SRC_MNT"
mount "$DEST_PART" "$DST_MNT"

trap 'umount -q "$SRC_MNT" 2>/dev/null || true; umount -q "$DST_MNT" 2>/dev/null || true; rmdir "$SRC_MNT" "$DST_MNT" 2>/dev/null || true' EXIT

info "Klonuję zawartość EFI (rsync)..."
rsync -aHAX --delete --info=stats1,progress2 "$SRC_MNT"/ "$DST_MNT"/
sync

# Wybór fallbacku \EFI\Boot\bootx64.efi
mkdir -p "$DST_MNT/EFI/Boot"

choose_fallback(){
  local pref="$1"
  shopt -s nocasematch
  local cand=""

  # 1) refind
  if [[ -f "$DST_MNT/EFI/refind/refind_x64.efi" ]]; then
    [[ "$pref" == "refind" || "$pref" == "auto" ]] && echo "refind" && return 0
  fi
  # 2) Manjaro GRUB
  if [[ -f "$DST_MNT/EFI/Manjaro/grubx64.efi" ]]; then
    [[ "$pref" == "manjaro" || "$pref" == "auto" ]] && echo "manjaro" && return 0
  fi
  # 3) Kali GRUB
  if [[ -f "$DST_MNT/EFI/Kali/grubx64.efi" ]]; then
    [[ "$pref" == "kali" || "$pref" == "auto" ]] && echo "kali" && return 0
  fi
  # 4) jakikolwiek grubx64.efi
  cand="$(find "$DST_MNT/EFI" -maxdepth 3 -iname grubx64.efi | head -n1 || true)"
  if [[ -n "$cand" ]]; then
    echo "anygrub"; return 0
  fi
  return 1
}

fallback=$(choose_fallback "$BOOT_PREF" || true)
case "$fallback" in
  refind)
    cp -f "$DST_MNT/EFI/refind/refind_x64.efi" "$DST_MNT/EFI/Boot/bootx64.efi"
    info "Fallback ustawiony: rEFInd → EFI/Boot/bootx64.efi"
    ;;
  manjaro)
    cp -f "$DST_MNT/EFI/Manjaro/grubx64.efi" "$DST_MNT/EFI/Boot/bootx64.efi"
    info "Fallback ustawiony: GRUB Manjaro → EFI/Boot/bootx64.efi"
    ;;
  kali)
    cp -f "$DST_MNT/EFI/Kali/grubx64.efi" "$DST_MNT/EFI/Boot/bootx64.efi"
    info "Fallback ustawiony: GRUB Kali → EFI/Boot/bootx64.efi"
    ;;
  anygrub)
    cand="$(find "$DST_MNT/EFI" -maxdepth 3 -iname grubx64.efi | head -n1)"
    cp -f "$cand" "$DST_MNT/EFI/Boot/bootx64.efi"
    info "Fallback ustawiony: $cand → EFI/Boot/bootx64.efi"
    ;;
  *)
    warn "Nie znalazłam rEFInd/GRUB do fallbacku. USB nadal zadziała z F9 (ręczny wybór pliku EFI)."
    ;;
esac
sync

# Opcjonalnie: dodaj wpis UEFI (nie zawsze trwały dla USB; HP bywa wybredny)
if $ADD_EFIBOOT && command -v efibootmgr >/dev/null 2>&1; then
  # Znajdź dysk urządzenia partycji
  disk=$(lsblk -pnlo PKNAME "$DEST_PART" | head -n1)
  partnum=$(lsblk -pnlo NAME,PARTNUM | awk -v p="$DEST_PART" '$1==p{print $2}')
  if [[ -n "$disk" && -n "$partnum" ]]; then
    info "Próba dodania wpisu UEFI przez efibootmgr..."
    efibootmgr -c -d "$disk" -p "$partnum" -L "$LABEL" -l "\\EFI\\Boot\\bootx64.efi" || warn "efibootmgr nie dodał wpisu (to normalne na części płyt/USB)."
  else
    warn "Nie udało się ustalić dysku/partnum dla efibootmgr."
  fi
fi

info "Skończone. Test: uruchom HP, ESC → F9 → wybierz USB, albo pozwól na automatyczny fallback EFI/Boot/bootx64.efi."

