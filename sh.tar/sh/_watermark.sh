#!/bin/bash
# add zank.png to *.jpg
echo "Hello, start add waremark znak.png ..............."
ls *.jpg
for i in *.jpg; do
  composite -gravity southeast znak.png "$i" "watermarked_$i"
done
ls
## end

